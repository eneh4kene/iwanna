// Wanna API Routes
// Phase 1C: Wanna Creation & AI Intent Parsing

import express from 'express';
import { z } from 'zod';
import { wannaService } from '../services/wannaService';
import { authService } from '../services/authService';
import { aiService } from '../services/aiService';
import { authenticateToken } from '../middleware/authenticate';

const router = express.Router();

// Validation schemas
const createWannaSchema = z.object({
    text: z.string()
        .min(3, 'Tell us a bit more about what you wanna do')
        .max(200, 'Keep it short and sweet (under 200 characters)'),
    moodEmoji: z.string().optional(),
    location: z.object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
        accuracy: z.number().positive(),
    }),
});

/**
 * POST /api/v1/wannas
 * Create a new wanna
 */
router.post('/', authenticateToken, async (req, res, next) => {
    try {
        // Validate input
        const data = createWannaSchema.parse(req.body);

        // Check rate limit
        const rateLimit = await authService.checkRateLimit(req.userId!);

        if (!rateLimit.allowed) {
            return res.status(429).json({
                error: 'Rate limit reached',
                message: `You've reached your daily limit. ${req.user.account_tier === 'anonymous'
                        ? 'Upgrade your account to create more wannas!'
                        : 'Try again tomorrow!'
                    }`,
                remaining: 0,
                accountTier: req.user.account_tier,
            });
        }

        // Create wanna
        const result = await wannaService.createWanna({
            userId: req.userId!,
            rawInput: data.text,
            moodEmoji: data.moodEmoji,
            location: data.location,
        });

        // Increment rate limit counter
        await authService.incrementWannaCount(req.userId!);

        res.status(201).json({
            success: true,
            wanna: {
                id: result.wannaId,
                intent: result.intent,
                locationName: result.locationName,
                expiresAt: result.expiresAt,
                remaining: rateLimit.remaining - 1,
            },
            message: `Finding your vibe in ${result.locationName}...`,
        });
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/v1/wannas/active
 * Get user's active wannas
 */
router.get('/active', authenticateToken, async (req, res, next) => {
    try {
        const wannas = await wannaService.getUserActiveWannas(req.userId!);

        res.json({
            success: true,
            wannas: wannas.map(w => ({
                id: w.id,
                text: w.raw_input,
                moodEmoji: w.mood_emoji,
                intent: w.intent,
                locationName: w.location_name,
                status: w.status,
                createdAt: w.created_at,
                expiresAt: w.expires_at,
            })),
        });
    } catch (error) {
        next(error);
    }
});

/**
 * DELETE /api/v1/wannas/:id
 * Cancel a wanna
 */
router.delete('/:id', authenticateToken, async (req, res, next) => {
    try {
        await wannaService.cancelWanna(req.params.id, req.userId!);

        res.json({
            success: true,
            message: 'Wanna cancelled',
        });
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/v1/wannas/suggestions
 * Get autocomplete suggestions
 */
router.get('/suggestions', authenticateToken, async (req, res, next) => {
    try {
        const { query } = req.query;

        if (!query || typeof query !== 'string') {
            return res.json({ suggestions: [] });
        }

        const suggestions = await aiService.getSuggestions(query);

        res.json({
            success: true,
            suggestions,
        });
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/v1/wannas/:id
 * Get specific wanna details
 */
router.get('/:id', authenticateToken, async (req, res, next) => {
    try {
        const wanna = await wannaService.getWannaById(req.params.id);

        if (!wanna) {
            return res.status(404).json({
                error: 'Wanna not found',
                message: 'This wanna doesn\'t exist or has expired',
            });
        }

        // Check if user owns this wanna
        if (wanna.user_id !== req.userId) {
            return res.status(403).json({
                error: 'Access denied',
                message: 'You can only view your own wannas',
            });
        }

        res.json({
            success: true,
            wanna: {
                id: wanna.id,
                text: wanna.raw_input,
                moodEmoji: wanna.mood_emoji,
                intent: wanna.intent,
                locationName: wanna.location_name,
                status: wanna.status,
                createdAt: wanna.created_at,
                expiresAt: wanna.expires_at,
                matchedAt: wanna.matched_at,
                cancelledAt: wanna.cancelled_at,
            },
        });
    } catch (error) {
        next(error);
    }
});

export default router;