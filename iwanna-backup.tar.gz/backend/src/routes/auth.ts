import express from 'express';
import { z } from 'zod';
import { authService } from '../services/authService';
import { authenticateToken } from '../middleware/authenticate';
import { logger } from '../utils/logger';

const router = express.Router();

// Validation schemas
const createAccountSchema = z.object({
    isOver18: z.boolean().refine(val => val === true, {
        message: 'Must be 18 or older to use Iwanna'
    }),
    deviceInfo: z.object({
        platform: z.enum(['ios', 'android', 'web']),
        osVersion: z.string(),
        appVersion: z.string(),
        deviceModel: z.string().optional(),
    }),
});

const recoverAccountSchema = z.object({
    recoveryPhrase: z.string()
        .min(10, 'Recovery phrase too short')
        .max(500, 'Recovery phrase too long'),
    deviceInfo: z.object({
        platform: z.enum(['ios', 'android', 'web']),
        osVersion: z.string(),
        appVersion: z.string(),
        deviceModel: z.string().optional(),
    }).optional(),
});

const refreshTokenSchema = z.object({
    refreshToken: z.string(),
});

const upgradeEmailSchema = z.object({
    email: z.string().email('Invalid email address'),
});

const upgradeSocialSchema = z.object({
    provider: z.enum(['google', 'apple']),
    credential: z.string(),
});

/**
 * POST /api/v1/auth/create-anonymous
 * Create Tier 1 anonymous account
 */
router.post('/create-anonymous', async (req, res, next) => {
    try {
        const data = createAccountSchema.parse(req.body);

        const result = await authService.createAnonymousAccount(
            data.deviceInfo,
            data.isOver18
        );

        logger.info('Anonymous account created', {
            userId: result.userId,
            username: result.username
        });

        res.status(201).json({
            success: true,
            data: {
                userId: result.userId,
                username: result.username,
                token: result.token,
                refreshToken: result.refreshToken,
                recoveryPhrase: result.recoveryPhrase, // SHOW ONCE!
                accountTier: 'anonymous',
            },
            message: 'Account created! Save your recovery phrase.',
        });
    } catch (error) {
        logger.error('Create anonymous account error:', error);
        next(error);
    }
});

/**
 * POST /api/v1/auth/recover
 * Recover account using recovery phrase
 */
router.post('/recover', async (req, res, next) => {
    try {
        const data = recoverAccountSchema.parse(req.body);
        const ipAddress = req.ip || req.connection.remoteAddress || 'unknown';

        const result = await authService.recoverAccount(
            data.recoveryPhrase,
            ipAddress,
            data.deviceInfo || {
                platform: 'web',
                osVersion: 'unknown',
                appVersion: '1.0.0'
            }
        );

        logger.info('Account recovered', {
            userId: result.userId,
            username: result.username
        });

        res.json({
            success: true,
            data: {
                userId: result.userId,
                username: result.username,
                token: result.token,
                refreshToken: result.refreshToken,
            },
            message: 'Welcome back! ✨',
        });
    } catch (error) {
        logger.error('Account recovery error:', error);
        next(error);
    }
});

/**
 * POST /api/v1/auth/refresh
 * Refresh access token
 */
router.post('/refresh', async (req, res, next) => {
    try {
        const data = refreshTokenSchema.parse(req.body);

        const result = await authService.refreshAccessToken(data.refreshToken);

        res.json({
            success: true,
            data: {
                token: result.token,
            },
        });
    } catch (error) {
        logger.error('Token refresh error:', error);
        next(error);
    }
});

/**
 * POST /api/v1/auth/logout
 * Logout and revoke refresh token
 */
router.post('/logout', async (req, res, next) => {
    try {
        const data = refreshTokenSchema.parse(req.body);

        await authService.logout(data.refreshToken);

        logger.info('User logged out');

        res.json({
            success: true,
            message: 'Logged out successfully',
        });
    } catch (error) {
        logger.error('Logout error:', error);
        next(error);
    }
});

/**
 * GET /api/v1/auth/me
 * Get current user info
 */
router.get('/me', authenticateToken, async (req, res, next) => {
    try {
        const user = await authService.getUserProfile(req.userId!);

        res.json({
            success: true,
            data: {
                user: {
                    id: user.id,
                    username: user.username,
                    accountTier: user.account_tier,
                    trustScore: user.trust_score,
                    wannasCreated: user.wannas_created_count,
                    podsJoined: user.pods_joined_count,
                    connectionsMade: user.connections_made_count,
                    createdAt: user.created_at,
                },
            },
        });
    } catch (error) {
        logger.error('Get user profile error:', error);
        next(error);
    }
});

/**
 * POST /api/v1/auth/upgrade/email
 * Upgrade to Tier 2 (add email)
 */
router.post('/upgrade/email', authenticateToken, async (req, res, next) => {
    try {
        const data = upgradeEmailSchema.parse(req.body);

        const result = await authService.upgradeToEmail(req.userId!, data.email);

        logger.info('Account upgraded to email tier', {
            userId: req.userId,
            email: data.email
        });

        res.json({
            success: true,
            data: {
                verificationRequired: result.verificationRequired,
            },
            message: 'Email added! You can now sync across devices.',
        });
    } catch (error) {
        logger.error('Email upgrade error:', error);
        next(error);
    }
});

/**
 * POST /api/v1/auth/upgrade/social
 * Upgrade to Tier 3 (social auth)
 */
router.post('/upgrade/social', authenticateToken, async (req, res, next) => {
    try {
        const data = upgradeSocialSchema.parse(req.body);

        // Verify social credential
        let socialProfile;

        if (data.provider === 'google') {
            // TODO: Implement Google token verification
            // For now, we'll mock it
            socialProfile = {
                sub: 'mock_google_id',
                email: 'mock@example.com'
            };
        } else if (data.provider === 'apple') {
            // TODO: Implement Apple token verification
            // For now, we'll mock it
            socialProfile = {
                sub: 'mock_apple_id',
                email: 'mock@example.com'
            };
        }

        if (!socialProfile) {
            throw new Error('Failed to verify social credential');
        }

        const result = await authService.upgradeToSocial(
            req.userId!,
            data.provider,
            socialProfile.sub,
            socialProfile.email
        );

        logger.info('Account upgraded to social tier', {
            userId: req.userId,
            provider: data.provider
        });

        res.json({
            success: true,
            message: 'Account upgraded! Full sync enabled.',
        });
    } catch (error) {
        logger.error('Social upgrade error:', error);
        next(error);
    }
});

/**
 * GET /api/v1/auth/rate-limit
 * Check current rate limit status
 */
router.get('/rate-limit', authenticateToken, async (req, res, next) => {
    try {
        const result = await authService.checkRateLimit(req.userId!);

        res.json({
            success: true,
            data: {
                allowed: result.allowed,
                remaining: result.remaining,
                accountTier: req.user.account_tier,
            },
        });
    } catch (error) {
        logger.error('Rate limit check error:', error);
        next(error);
    }
});

export default router;