import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { getActivePods, getPod, leavePod, completePod } from '../controllers/podController';

const router = Router();

// Get user's active pods
router.get('/active', asyncHandler(getActivePods));

// Get specific pod
router.get('/:id', asyncHandler(getPod));

// Leave a pod
router.post('/:id/leave', asyncHandler(leavePod));

// Complete a pod
router.post('/:id/complete', asyncHandler(completePod));

export { router as podRoutes };
