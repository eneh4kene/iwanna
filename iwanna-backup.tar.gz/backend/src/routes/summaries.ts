import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { getVibeSummaries, getVibeSummary } from '../controllers/summaryController';

const router = Router();

// Get user's vibe summaries
router.get('/', asyncHandler(getVibeSummaries));

// Get specific vibe summary
router.get('/:id', asyncHandler(getVibeSummary));

export { router as summaryRoutes };
