import { Router } from 'express';
import authRoutes from './auth';
import wannaRoutes from './wannas';

// Create main router
export const setupRoutes = (): Router => {
    const router = Router();

    // Health check route
    router.get('/health', (req, res) => {
        res.json({
            success: true,
            message: 'Iwanna API is healthy',
            timestamp: new Date().toISOString(),
        });
    });

    // API routes
    router.use('/auth', authRoutes);
    router.use('/wannas', wannaRoutes);

    return router;
};
