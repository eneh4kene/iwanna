import { Router } from 'express';
import { asyncHandler } from '../middleware/errorHandler';
import { getChatMessages, sendMessage } from '../controllers/chatController';

const router = Router();

// Get chat messages for a pod
router.get('/pods/:podId/messages', asyncHandler(getChatMessages));

// Send a message
router.post('/pods/:podId/messages', asyncHandler(sendMessage));

export { router as chatRoutes };
