import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { config, serverConfig, loggingConfig } from './config';
import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { rateLimiter } from './middleware/rateLimiter';
import { setupRoutes } from './routes';
import { setupWebSocket } from './services/websocket';
import { logger } from './utils/logger';
import { connectDatabase } from './services/database';
import { connectRedis } from './services/redis';

// Create Express app
const app = express();
const server = createServer(app);

// Create Socket.IO server
const io = new SocketIOServer(server, {
    cors: {
        origin: config.server.corsOrigins,
        methods: ['GET', 'POST'],
        credentials: true,
    },
    transports: ['websocket'],
});

// Trust proxy for accurate IP addresses
app.set('trust proxy', 1);

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
    crossOriginEmbedderPolicy: false,
}));

// CORS middleware
app.use(cors({
    origin: serverConfig.corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
}));

// Compression middleware
app.use(compression());

// Request logging
app.use(morgan(loggingConfig.format, {
    stream: {
        write: (message: string) => logger.info(message.trim()),
    },
}));

// Custom request logger
app.use(requestLogger);

// Rate limiting
app.use(rateLimiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: serverConfig.env,
        version: process.env['npm_package_version'] || '1.0.0',
    });
});

// API routes
app.use(`/api/${serverConfig.apiVersion}`, setupRoutes());

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: {
            code: 'NOT_FOUND',
            message: `Route ${req.method} ${req.originalUrl} not found`,
        },
    });
});

// Global error handler
app.use(errorHandler);

// Initialize services
const initializeServices = async (): Promise<void> => {
    try {
        logger.info('🚀 Initializing Iwanna backend services...');

        // Connect to database
        await connectDatabase();
        logger.info('✅ Database connected');

        // Connect to Redis
        await connectRedis();
        logger.info('✅ Redis connected');

        // Setup WebSocket
        setupWebSocket(io);
        logger.info('✅ WebSocket server configured');

        logger.info('🎉 All services initialized successfully');
    } catch (error) {
        logger.error('❌ Failed to initialize services:', error);
        process.exit(1);
    }
};

// Graceful shutdown
const gracefulShutdown = (signal: string): void => {
    logger.info(`📡 Received ${signal}. Starting graceful shutdown...`);

    server.close(() => {
        logger.info('🔌 HTTP server closed');

        // Close database connections
        // Close Redis connections
        // Close other services

        logger.info('👋 Graceful shutdown completed');
        process.exit(0);
    });

    // Force close after 30 seconds
    setTimeout(() => {
        logger.error('⚠️ Forced shutdown after timeout');
        process.exit(1);
    }, 30000);
};

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    logger.error('💥 Uncaught Exception:', error);
    process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
    logger.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});

// Handle shutdown signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
const startServer = async (): Promise<void> => {
    try {
        // Initialize services first
        await initializeServices();

        // Start HTTP server
        server.listen(serverConfig.port, () => {
            logger.info(`🌟 Iwanna backend server running on port ${serverConfig.port}`);
            logger.info(`📱 Environment: ${serverConfig.env}`);
            logger.info(`🔗 API URL: http://localhost:${serverConfig.port}/api/${serverConfig.apiVersion}`);
            logger.info(`⚡ WebSocket URL: http://localhost:${serverConfig.port}`);
            logger.info('🚀 Ready to connect people through moments of impulse!');
        });
    } catch (error) {
        logger.error('❌ Failed to start server:', error);
        process.exit(1);
    }
};

// Start the server
startServer().catch((error) => {
    logger.error('💥 Fatal error starting server:', error);
    process.exit(1);
});

export { app, server, io };
