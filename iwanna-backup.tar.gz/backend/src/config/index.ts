import dotenv from 'dotenv';
import { z } from 'zod';

// Load environment variables
dotenv.config();

// Environment validation schema
const envSchema = z.object({
    // Database
    DATABASE_URL: z.string().url(),
    DB_HOST: z.string().default('localhost'),
    DB_PORT: z.string().transform(Number).default('5432'),
    DB_NAME: z.string().default('iwanna_db'),
    DB_USER: z.string().default('iwanna'),
    DB_PASSWORD: z.string().default('iwanna_password'),

    // Redis
    REDIS_URL: z.string().url().default('redis://localhost:6379'),
    REDIS_HOST: z.string().default('localhost'),
    REDIS_PORT: z.string().transform(Number).default('6379'),
    REDIS_PASSWORD: z.string().optional(),

    // JWT
    JWT_ACCESS_SECRET: z.string().min(32),
    JWT_REFRESH_SECRET: z.string().min(32),
    JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
    JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),

    // Server
    PORT: z.string().transform(Number).default('3001'),
    NODE_ENV: z.enum(['development', 'staging', 'production']).default('development'),
    API_VERSION: z.string().default('v1'),

    // CORS
    CORS_ORIGIN: z.string().default('http://localhost:8081,http://localhost:19006'),

    // Rate Limiting
    RATE_LIMIT_WINDOW_MS: z.string().transform(Number).default('900000'), // 15 minutes
    RATE_LIMIT_MAX_REQUESTS: z.string().transform(Number).default('100'),

    // Tier Rate Limits
    TIER1_WANNAS_PER_DAY: z.string().transform(Number).default('5'),
    TIER2_WANNAS_PER_DAY: z.string().transform(Number).default('10'),
    TIER3_WANNAS_PER_DAY: z.string().transform(Number).default('999'),

    // SMS Service
    TWILIO_ACCOUNT_SID: z.string().optional(),
    TWILIO_AUTH_TOKEN: z.string().optional(),
    TWILIO_PHONE_NUMBER: z.string().optional(),

    // AI Services
    OPENAI_API_KEY: z.string().optional(),
    OPENAI_MODEL: z.string().default('gpt-4o-mini'),
    OPENAI_EMBEDDING_MODEL: z.string().default('text-embedding-3-small'),
    ANTHROPIC_API_KEY: z.string().optional(),

    // Vector Database
    PINECONE_API_KEY: z.string().optional(),
    PINECONE_ENVIRONMENT: z.string().optional(),

    // Logging
    LOG_LEVEL: z.enum(['error', 'warn', 'info', 'debug']).default('info'),
    LOG_FORMAT: z.enum(['combined', 'common', 'dev', 'short', 'tiny']).default('combined'),

    // Security
    BCRYPT_ROUNDS: z.string().transform(Number).default('12'),
    SESSION_SECRET: z.string().min(32),

    // Feature Flags
    ENABLE_ANALYTICS: z.string().transform(val => val === 'true').default('false'),
    ENABLE_CRASH_REPORTING: z.string().transform(val => val === 'true').default('false'),
    ENABLE_AI_FEATURES: z.string().transform(val => val === 'true').default('true'),
});

// Validate and parse environment variables
const parseEnv = (): z.infer<typeof envSchema> => {
    try {
        return envSchema.parse(process.env);
    } catch (error) {
        if (error instanceof z.ZodError) {
            console.error('❌ Environment validation failed:');
            error.errors.forEach((err) => {
                console.error(`  - ${err.path.join('.')}: ${err.message}`);
            });
            process.exit(1);
        }
        throw error;
    }
};

export const config = parseEnv();

// Database configuration
export const dbConfig = {
    connectionString: config.DATABASE_URL,
    host: config.DB_HOST,
    port: config.DB_PORT,
    database: config.DB_NAME,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    ssl: config.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    max: 20, // Maximum number of clients in the pool
    idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
    connectionTimeoutMillis: 2000, // Return an error after 2 seconds if connection could not be established
};

// Redis configuration
export const redisConfig = {
    url: config.REDIS_URL,
    host: config.REDIS_HOST,
    port: config.REDIS_PORT,
    ...(config.REDIS_PASSWORD && { password: config.REDIS_PASSWORD }),
    retryDelayOnFailover: 100,
    maxRetriesPerRequest: 3,
    lazyConnect: true,
};

// JWT configuration
export const jwtConfig = {
    accessSecret: config.JWT_ACCESS_SECRET,
    refreshSecret: config.JWT_REFRESH_SECRET,
    accessExpiresIn: config.JWT_ACCESS_EXPIRES_IN,
    refreshExpiresIn: config.JWT_REFRESH_EXPIRES_IN,
};

// Server configuration
export const serverConfig = {
    port: config.PORT,
    env: config.NODE_ENV,
    apiVersion: config.API_VERSION,
    corsOrigins: config.CORS_ORIGIN.split(',').map(origin => origin.trim()),
};

// Rate limiting configuration
export const rateLimitConfig = {
    windowMs: config.RATE_LIMIT_WINDOW_MS,
    max: config.RATE_LIMIT_MAX_REQUESTS,
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
};

// SMS configuration
export const smsConfig = {
    twilioAccountSid: config.TWILIO_ACCOUNT_SID,
    twilioAuthToken: config.TWILIO_AUTH_TOKEN,
    twilioPhoneNumber: config.TWILIO_PHONE_NUMBER,
};

// AI configuration
export const aiConfig = {
    openaiApiKey: config.OPENAI_API_KEY,
    openaiModel: config.OPENAI_MODEL,
    openaiEmbeddingModel: config.OPENAI_EMBEDDING_MODEL,
    anthropicApiKey: config.ANTHROPIC_API_KEY,
    enableFeatures: config.ENABLE_AI_FEATURES,
};

// Vector database configuration
export const vectorDbConfig = {
    pineconeApiKey: config.PINECONE_API_KEY,
    pineconeEnvironment: config.PINECONE_ENVIRONMENT,
};

// Logging configuration
export const loggingConfig = {
    level: config.LOG_LEVEL,
    format: config.LOG_FORMAT,
};

// Security configuration
export const securityConfig = {
    bcryptRounds: config.BCRYPT_ROUNDS,
    sessionSecret: config.SESSION_SECRET,
};

// Feature flags
export const featureFlags = {
    analytics: config.ENABLE_ANALYTICS,
    crashReporting: config.ENABLE_CRASH_REPORTING,
    aiFeatures: config.ENABLE_AI_FEATURES,
};

// Export all configurations
export default {
    db: dbConfig,
    redis: redisConfig,
    jwt: jwtConfig,
    server: serverConfig,
    rateLimit: rateLimitConfig,
    sms: smsConfig,
    ai: aiConfig,
    vectorDb: vectorDbConfig,
    logging: loggingConfig,
    security: securityConfig,
    features: featureFlags,
};

// Individual configs are already exported above
