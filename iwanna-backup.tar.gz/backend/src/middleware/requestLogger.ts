import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';
import { randomUUID } from 'crypto';

// Extend Request interface to include request ID
declare global {
    namespace Express {
        interface Request {
            requestId: string;
            startTime: number;
        }
    }
}

// Request logger middleware
export const requestLogger = (req: Request, res: Response, next: NextFunction): void => {
    // Generate unique request ID
    req.requestId = randomUUID();
    req.startTime = Date.now();

    // Log request start
    logger.info('Request started', {
        requestId: req.requestId,
        method: req.method,
        url: req.url,
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        userId: (req as any).user?.id,
    });

    // Override res.end to log response
    const originalEnd = res.end;
    res.end = function (chunk?: any, encoding?: any) {
        const duration = Date.now() - req.startTime;

        logger.info('Request completed', {
            requestId: req.requestId,
            method: req.method,
            url: req.url,
            statusCode: res.statusCode,
            duration: `${duration}ms`,
            ip: req.ip,
            userId: (req as any).user?.id,
        });

        // Call original end method
        originalEnd.call(this, chunk, encoding);
    };

    next();
};
