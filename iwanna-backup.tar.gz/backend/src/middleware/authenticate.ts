import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { query } from '../services/database';
import { logger } from '../utils/logger';

// Extend Express Request type
declare global {
    namespace Express {
        interface Request {
            user?: any;
            userId?: string;
        }
    }
}

export const authenticateToken = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader?.split(' ')[1]; // "Bearer TOKEN"

    if (!token) {
        return res.status(401).json({
            success: false,
            error: {
                code: 'AUTHENTICATION_REQUIRED',
                message: 'Please sign in to continue'
            }
        });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET!) as any;

        if (decoded.type !== 'access') {
            return res.status(403).json({
                success: false,
                error: {
                    code: 'INVALID_TOKEN_TYPE',
                    message: 'Invalid token type'
                }
            });
        }

        // Load user from database
        const user = await query(`
            SELECT id, username, account_tier, is_banned, ban_reason, trust_score
            FROM users 
            WHERE id = $1
        `, [decoded.userId]);

        if (user.rows.length === 0) {
            return res.status(401).json({
                success: false,
                error: {
                    code: 'USER_NOT_FOUND',
                    message: 'User not found'
                }
            });
        }

        const userData = user.rows[0];

        if (userData.is_banned) {
            return res.status(403).json({
                success: false,
                error: {
                    code: 'ACCOUNT_SUSPENDED',
                    message: userData.ban_reason || 'Your account has been suspended'
                }
            });
        }

        // Update last active
        await query(`
            UPDATE users 
            SET last_active_at = NOW()
            WHERE id = $1
        `, [decoded.userId]);

        // Attach to request
        req.user = userData;
        req.userId = userData.id;

        next();
    } catch (error) {
        logger.error('Authentication error:', error);

        if (error instanceof jwt.TokenExpiredError) {
            return res.status(401).json({
                success: false,
                error: {
                    code: 'TOKEN_EXPIRED',
                    message: 'Please refresh your session'
                }
            });
        }

        return res.status(403).json({
            success: false,
            error: {
                code: 'INVALID_TOKEN',
                message: 'Authentication failed'
            }
        });
    }
};

export const optionalAuth = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader?.split(' ')[1];

    if (!token) {
        return next(); // Continue without auth
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET!) as any;
        const user = await query(`
            SELECT id, username, account_tier, is_banned
            FROM users 
            WHERE id = $1
        `, [decoded.userId]);

        if (user.rows.length > 0 && !user.rows[0].is_banned) {
            req.user = user.rows[0];
            req.userId = user.rows[0].id;
        }
    } catch (error) {
        // Silent fail - continue without auth
        logger.debug('Optional auth failed:', error);
    }

    next();
};
