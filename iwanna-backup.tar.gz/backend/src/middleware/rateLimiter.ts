import rateLimit from 'express-rate-limit';
import { rateLimitConfig } from '../config';
import { logger } from '../utils/logger';

// Create rate limiter middleware
export const rateLimiter = rateLimit({
    windowMs: rateLimitConfig.windowMs,
    max: rateLimitConfig.max,
    message: {
        success: false,
        error: {
            code: 'RATE_LIMIT_EXCEEDED',
            message: rateLimitConfig.message,
        },
    },
    standardHeaders: rateLimitConfig.standardHeaders,
    legacyHeaders: rateLimitConfig.legacyHeaders,
    handler: (req, res) => {
        logger.warn('Rate limit exceeded', {
            ip: req.ip,
            url: req.url,
            method: req.method,
            userAgent: req.get('User-Agent'),
        });

        res.status(429).json({
            success: false,
            error: {
                code: 'RATE_LIMIT_EXCEEDED',
                message: rateLimitConfig.message,
            },
        });
    },
    skip: (req) => {
        // Skip rate limiting for health checks
        return req.url === '/health';
    },
});

// Strict rate limiter for authentication endpoints
export const authRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts per window
    message: {
        success: false,
        error: {
            code: 'AUTH_RATE_LIMIT_EXCEEDED',
            message: 'Too many authentication attempts, please try again later',
        },
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        logger.warn('Auth rate limit exceeded', {
            ip: req.ip,
            url: req.url,
            method: req.method,
        });

        res.status(429).json({
            success: false,
            error: {
                code: 'AUTH_RATE_LIMIT_EXCEEDED',
                message: 'Too many authentication attempts, please try again later',
            },
        });
    },
});

// Lenient rate limiter for general API endpoints
export const apiRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // 100 requests per window
    message: {
        success: false,
        error: {
            code: 'API_RATE_LIMIT_EXCEEDED',
            message: 'Too many API requests, please try again later',
        },
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        logger.warn('API rate limit exceeded', {
            ip: req.ip,
            url: req.url,
            method: req.method,
        });

        res.status(429).json({
            success: false,
            error: {
                code: 'API_RATE_LIMIT_EXCEEDED',
                message: 'Too many API requests, please try again later',
            },
        });
    },
});
