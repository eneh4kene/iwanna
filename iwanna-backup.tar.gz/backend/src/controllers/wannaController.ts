import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { ApiResponse } from '../types';

// Create a new wanna
export const createWanna = async (req: Request, res: Response): Promise<void> => {
    const { text, mood, location } = req.body;

    logger.info('Creating wanna', { text, mood, location });

    // TODO: Implement wanna creation logic
    const response: ApiResponse<any> = {
        success: true,
        data: { id: 'mock-wanna-id', text, mood, location },
    };

    res.status(201).json(response);
};

// Get user's active wannas
export const getActiveWannas = async (req: Request, res: Response): Promise<void> => {
    logger.info('Getting active wannas');

    // TODO: Implement get active wannas logic
    const response: ApiResponse<any[]> = {
        success: true,
        data: [],
    };

    res.status(200).json(response);
};

// Cancel a wanna
export const cancelWanna = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;

    logger.info('Cancelling wanna', { id });

    // TODO: Implement wanna cancellation logic
    const response: ApiResponse<{ message: string }> = {
        success: true,
        data: { message: 'Wanna cancelled successfully' },
    };

    res.status(200).json(response);
};
