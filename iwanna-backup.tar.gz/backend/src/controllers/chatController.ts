import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { ApiResponse } from '../types';

// Get chat messages for a pod
export const getChatMessages = async (req: Request, res: Response): Promise<void> => {
    const { podId } = req.params;

    logger.info('Getting chat messages', { podId });

    // TODO: Implement get chat messages logic
    const response: ApiResponse<any[]> = {
        success: true,
        data: [],
    };

    res.status(200).json(response);
};

// Send a message
export const sendMessage = async (req: Request, res: Response): Promise<void> => {
    const { podId } = req.params;
    const { content } = req.body;

    logger.info('Sending message', { podId, content });

    // TODO: Implement send message logic
    const response: ApiResponse<any> = {
        success: true,
        data: { id: 'mock-message-id', content, podId },
    };

    res.status(201).json(response);
};
