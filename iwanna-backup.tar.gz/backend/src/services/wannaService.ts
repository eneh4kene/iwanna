// Wanna Service for Creating and Managing Wannas
// Phase 1C: Wanna Creation & AI Intent Parsing

import { v4 as uuidv4 } from 'uuid';
import { db } from './database';
import { redis } from './redis';
import { aiService, Intent } from './aiService';
import { locationService } from './locationService';

export interface CreateWannaInput {
    userId: string;
    rawInput: string;
    moodEmoji?: string;
    location: {
        latitude: number;
        longitude: number;
        accuracy: number;
    };
}

export interface CreateWannaResult {
    wannaId: string;
    intent: Intent;
    locationName: string;
    expiresAt: Date;
}

class WannaService {
    /**
     * Create a new wanna
     */
    async createWanna(input: CreateWannaInput): Promise<CreateWannaResult> {
        const { userId, rawInput, moodEmoji, location } = input;

        // Validate location
        if (!locationService.isValidLocation(location.latitude, location.longitude)) {
            throw new Error('Invalid location coordinates');
        }

        // Get location context
        const locationContext = await locationService.reverseGeocode(
            location.latitude,
            location.longitude
        );

        // Parse intent with AI
        const { intent, embedding } = await aiService.parseIntent(
            rawInput,
            moodEmoji,
            locationContext || undefined
        );

        // Create wanna record
        const wannaId = uuidv4();
        const expiresAt = new Date(Date.now() + 6 * 60 * 60 * 1000); // 6 hours

        const wanna = await db.wannas.create({
            id: wannaId,
            user_id: userId,
            raw_input: rawInput,
            mood_emoji: moodEmoji,
            intent: intent,
            embedding: JSON.stringify(embedding), // Store as JSON string for now
            location: `POINT(${location.longitude} ${location.latitude})`,
            location_accuracy: location.accuracy,
            location_name: locationContext?.formatted || 'Unknown location',
            status: 'active',
            expires_at: expiresAt,
        });

        // Cache for quick matching (Redis)
        if (redis) {
            await redis.setex(
                `wanna:${wannaId}`,
                21600, // 6 hours
                JSON.stringify({
                    id: wannaId,
                    user_id: userId,
                    intent,
                    location: {
                        lat: location.latitude,
                        lng: location.longitude,
                    },
                    created_at: Date.now(),
                })
            );

            // Add to geospatial index for proximity search
            await redis.geoadd(
                'active_wannas',
                location.longitude,
                location.latitude,
                wannaId
            );
        }

        // Increment user's wanna count (for rate limiting)
        await db.users.increment('wannas_today', { where: { id: userId } });
        await db.users.increment('wannas_created_count', { where: { id: userId } });
        await db.users.update(
            { last_wanna_at: new Date() },
            { where: { id: userId } }
        );

        // Queue for matching (will implement in Phase 1D)
        await this.queueForMatching(wannaId);

        return {
            wannaId,
            intent,
            locationName: locationService.getFriendlyLocationName(locationContext),
            expiresAt,
        };
    }

    /**
     * Cancel a wanna
     */
    async cancelWanna(wannaId: string, userId: string): Promise<void> {
        const wanna = await db.wannas.findOne({
            where: {
                id: wannaId,
                user_id: userId,
            },
        });

        if (!wanna) {
            throw new Error('Wanna not found');
        }

        if (wanna.status !== 'active') {
            throw new Error('Wanna cannot be cancelled');
        }

        await wanna.update({
            status: 'cancelled',
            cancelled_at: new Date(),
        });

        // Remove from Redis caches
        if (redis) {
            await redis.del(`wanna:${wannaId}`);
            await redis.zrem('active_wannas', wannaId);
        }
    }

    /**
     * Get user's active wannas
     */
    async getUserActiveWannas(userId: string) {
        return await db.wannas.findAll({
            where: {
                user_id: userId,
                status: 'active',
            },
            order: [['created_at', 'DESC']],
        });
    }

    /**
     * Get nearby wannas for matching (Phase 1D will use this)
     */
    async getNearbyWannas(
        latitude: number,
        longitude: number,
        maxDistanceMiles: number = 5.0,
        limit: number = 10
    ) {
        // Use Redis geospatial search for fast proximity lookup
        if (!redis) return [];

        const nearbyWannaIds = await redis.georadius(
            'active_wannas',
            longitude,
            latitude,
            maxDistanceMiles,
            'mi',
            'WITHCOORD',
            'COUNT',
            limit
        );

        if (!nearbyWannaIds || nearbyWannaIds.length === 0) {
            return [];
        }

        // Get full wanna data from database
        const wannaIds = nearbyWannaIds.map((item: any) => item[0]);
        const wannas = await db.wannas.findAll({
            where: {
                id: wannaIds,
                status: 'active',
            },
        });

        return wannas;
    }

    /**
     * Queue wanna for matching (placeholder for Phase 1D)
     */
    private async queueForMatching(wannaId: string): Promise<void> {
        // Add to matching queue (will be processed by matching worker in Phase 1D)
        if (redis) {
            await redis.lpush('matching_queue', wannaId);
        }

        console.log(`[Wanna ${wannaId}] Queued for matching`);
    }

    /**
     * Clean up expired wannas (cron job)
     */
    async cleanupExpiredWannas(): Promise<number> {
        const expired = await db.wannas.update(
            { status: 'expired' },
            {
                where: {
                    status: 'active',
                    expires_at: { $lt: new Date() },
                },
            }
        );

        return expired.length; // Number of rows updated
    }

    /**
     * Get wanna by ID
     */
    async getWannaById(wannaId: string) {
        return await db.wannas.findByPk(wannaId);
    }

    /**
     * Update wanna status
     */
    async updateWannaStatus(wannaId: string, status: string, additionalData?: any) {
        const updateData: any = { status };

        if (status === 'matched') {
            updateData.matched_at = new Date();
        }

        if (additionalData) {
            Object.assign(updateData, additionalData);
        }

        return await db.wannas.update(updateData, {
            where: { id: wannaId },
        });
    }
}

export const wannaService = new WannaService();
