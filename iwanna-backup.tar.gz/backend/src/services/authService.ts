import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { generateMnemonic } from 'bip39';
import crypto from 'crypto';
import { query, transaction } from './database';
import { logger } from '../utils/logger';

interface CreateAnonymousAccountResult {
    userId: string;
    username: string;
    token: string;
    refreshToken: string;
    recoveryPhrase: string; // Only returned once!
}

interface DeviceInfo {
    platform: string;
    osVersion: string;
    appVersion: string;
    deviceModel?: string;
}

class AuthService {
    /**
     * Generate anonymous username
     * Format: AdjNoun_4digits (e.g., "CuriousVibe_8234")
     */
    private generateUsername(): string {
        const adjectives = [
            'Curious', 'Vibrant', 'Chill', 'Creative', 'Energetic',
            'Mellow', 'Spontaneous', 'Peaceful', 'Bold', 'Gentle',
            'Warm', 'Cool', 'Bright', 'Calm', 'Lively',
            'Mindful', 'Open', 'Quiet', 'Radiant', 'Serene'
        ];

        const nouns = [
            'Vibe', 'Soul', 'Spirit', 'Mind', 'Heart',
            'Wave', 'Flow', 'Pulse', 'Beat', 'Rhythm',
            'Dream', 'Echo', 'Spark', 'Light', 'Moon',
            'Sun', 'Star', 'Cloud', 'Wind', 'Rain'
        ];

        const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
        const noun = nouns[Math.floor(Math.random() * nouns.length)];
        const num = Math.floor(1000 + Math.random() * 9000);

        return `${adj}${noun}_${num}`;
    }

    /**
     * Generate device fingerprint for fraud detection
     */
    generateDeviceFingerprint(deviceInfo: DeviceInfo): string {
        const dataString = JSON.stringify({
            platform: deviceInfo.platform,
            osVersion: deviceInfo.osVersion,
            appVersion: deviceInfo.appVersion,
            deviceModel: deviceInfo.deviceModel || 'unknown',
        });

        return crypto
            .createHash('sha256')
            .update(dataString)
            .digest('hex');
    }

    /**
     * Create Tier 1 anonymous account
     */
    async createAnonymousAccount(
        deviceInfo: DeviceInfo,
        isOver18: boolean
    ): Promise<CreateAnonymousAccountResult> {
        if (!isOver18) {
            throw new Error('Must be 18 or older to use Iwanna');
        }

        return await transaction(async (client) => {
            // Generate unique username (check for collisions)
            let username: string;
            let attempts = 0;

            do {
                username = this.generateUsername();
                const existing = await client.query(
                    'SELECT id FROM users WHERE username = $1',
                    [username]
                );
                if (existing.rows.length === 0) break;
                attempts++;
            } while (attempts < 10);

            if (attempts >= 10) {
                throw new Error('Unable to generate unique username');
            }

            // Generate recovery phrase (12 words)
            const recoveryPhrase = generateMnemonic(128); // 12 words
            const recoveryPhraseHash = await bcrypt.hash(
                recoveryPhrase.toLowerCase().trim(),
                parseInt(process.env.BCRYPT_ROUNDS || '10')
            );

            // Generate device fingerprint
            const deviceFingerprint = this.generateDeviceFingerprint(deviceInfo);

            // Create user
            const userId = uuidv4();
            await client.query(`
                INSERT INTO users (
                    id, username, account_tier, recovery_phrase_hash, 
                    device_fingerprint, is_18_plus, age_verified_at, trust_score
                ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7)
            `, [
                userId,
                username,
                'anonymous',
                recoveryPhraseHash,
                deviceFingerprint,
                true,
                100
            ]);

            // Generate tokens
            const { token, refreshToken } = await this.generateTokens(userId, 'anonymous', client);

            return {
                userId,
                username,
                token,
                refreshToken,
                recoveryPhrase, // ONLY TIME THIS IS RETURNED
            };
        });
    }

    /**
     * Generate JWT access token and refresh token
     */
    async generateTokens(userId: string, accountTier: string, client?: any): Promise<{ token: string; refreshToken: string }> {
        const dbClient = client || await query;

        // Access token (short-lived)
        const token = jwt.sign(
            {
                userId,
                accountTier,
                type: 'access'
            },
            process.env.JWT_ACCESS_SECRET!,
            { expiresIn: '15m' }
        );

        // Refresh token (long-lived)
        const refreshTokenValue = uuidv4();
        const refreshTokenHash = crypto
            .createHash('sha256')
            .update(refreshTokenValue)
            .digest('hex');

        // Store refresh token in database
        const expiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000); // 90 days

        if (client) {
            await client.query(`
                INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
                VALUES ($1, $2, $3)
            `, [userId, refreshTokenHash, expiresAt]);
        } else {
            await query(`
                INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
                VALUES ($1, $2, $3)
            `, [userId, refreshTokenHash, expiresAt]);
        }

        const refreshToken = jwt.sign(
            {
                userId,
                tokenId: refreshTokenValue,
                type: 'refresh'
            },
            process.env.JWT_REFRESH_SECRET!,
            { expiresIn: '90d' }
        );

        return { token, refreshToken };
    }

    /**
     * Recover account using recovery phrase
     */
    async recoverAccount(
        recoveryPhrase: string,
        ipAddress: string,
        deviceInfo: DeviceInfo
    ): Promise<{ userId: string; username: string; token: string; refreshToken: string }> {
        const normalizedPhrase = recoveryPhrase.toLowerCase().trim();

        // Rate limiting check (using Redis would be better, but for now we'll use DB)
        const attemptKey = `recovery_attempts:${ipAddress}`;
        const attempts = await query(`
            SELECT COUNT(*) as count FROM recovery_attempts 
            WHERE ip_address = $1 AND attempted_at > NOW() - INTERVAL '1 hour'
        `, [ipAddress]);

        const attemptCount = parseInt(attempts.rows[0].count);

        if (attemptCount >= 5) {
            // Log suspicious activity
            await query(`
                INSERT INTO recovery_attempts (attempted_phrase, ip_address, device_info, success)
                VALUES ($1, $2, $3, $4)
            `, [
                normalizedPhrase.substring(0, 50),
                ipAddress,
                JSON.stringify(deviceInfo),
                false
            ]);

            throw new Error('Too many recovery attempts. Try again in 1 hour.');
        }

        // Find user by recovery phrase
        // NOTE: This is slow because we must check all users
        // For production with many users, consider using HMAC indexing
        const users = await query(`
            SELECT id, username, recovery_phrase_hash, account_tier
            FROM users 
            WHERE recovery_phrase_hash IS NOT NULL AND is_banned = false
        `);

        for (const user of users.rows) {
            const isMatch = await bcrypt.compare(normalizedPhrase, user.recovery_phrase_hash);

            if (isMatch) {
                // Success! Log it
                await query(`
                    INSERT INTO recovery_attempts (attempted_phrase, ip_address, device_info, success, user_id)
                    VALUES ($1, $2, $3, $4, $5)
                `, [
                    normalizedPhrase.substring(0, 50),
                    ipAddress,
                    JSON.stringify(deviceInfo),
                    true,
                    user.id
                ]);

                // Generate new tokens
                const { token, refreshToken } = await this.generateTokens(user.id, user.account_tier);

                // Update device fingerprint and last active
                await query(`
                    UPDATE users 
                    SET device_fingerprint = $1, last_active_at = NOW()
                    WHERE id = $2
                `, [this.generateDeviceFingerprint(deviceInfo), user.id]);

                return {
                    userId: user.id,
                    username: user.username,
                    token,
                    refreshToken,
                };
            }
        }

        // No match - log failed attempt
        await query(`
            INSERT INTO recovery_attempts (attempted_phrase, ip_address, device_info, success)
            VALUES ($1, $2, $3, $4)
        `, [
            normalizedPhrase.substring(0, 50),
            ipAddress,
            JSON.stringify(deviceInfo),
            false
        ]);

        throw new Error('Invalid recovery phrase');
    }

    /**
     * Refresh access token
     */
    async refreshAccessToken(refreshToken: string): Promise<{ token: string }> {
        try {
            const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as any;

            // Hash the token ID to check database
            const tokenHash = crypto
                .createHash('sha256')
                .update(decoded.tokenId)
                .digest('hex');

            // Check if refresh token exists and is valid
            const storedToken = await query(`
                SELECT rt.*, u.account_tier, u.is_banned
                FROM refresh_tokens rt
                JOIN users u ON rt.user_id = u.id
                WHERE rt.token_hash = $1 AND rt.user_id = $2 
                AND rt.revoked = false AND rt.expires_at > NOW()
            `, [tokenHash, decoded.userId]);

            if (storedToken.rows.length === 0) {
                throw new Error('Invalid refresh token');
            }

            const tokenData = storedToken.rows[0];

            if (tokenData.is_banned) {
                throw new Error('User banned');
            }

            // Update last used
            await query(`
                UPDATE refresh_tokens 
                SET last_used_at = NOW()
                WHERE token_hash = $1
            `, [tokenHash]);

            // Generate new access token
            const token = jwt.sign(
                {
                    userId: decoded.userId,
                    accountTier: tokenData.account_tier,
                    type: 'access'
                },
                process.env.JWT_ACCESS_SECRET!,
                { expiresIn: '15m' }
            );

            return { token };
        } catch (error) {
            logger.error('Token refresh failed:', error);
            throw new Error('Invalid refresh token');
        }
    }

    /**
     * Logout (revoke refresh token)
     */
    async logout(refreshToken: string): Promise<void> {
        try {
            const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as any;

            const tokenHash = crypto
                .createHash('sha256')
                .update(decoded.tokenId)
                .digest('hex');

            await query(`
                UPDATE refresh_tokens 
                SET revoked = true, revoked_at = NOW()
                WHERE token_hash = $1
            `, [tokenHash]);
        } catch (error) {
            // Silent fail - token might already be invalid
            logger.warn('Logout failed:', error);
        }
    }

    /**
     * Upgrade Tier 1 to Tier 2 (add email)
     */
    async upgradeToEmail(
        userId: string,
        email: string
    ): Promise<{ success: boolean; verificationRequired: boolean }> {
        // Check if email already exists
        const existing = await query(`
            SELECT id FROM users WHERE email = $1
        `, [email]);

        if (existing.rows.length > 0) {
            throw new Error('Email already in use');
        }

        // Generate email verification token
        const verificationToken = crypto.randomBytes(32).toString('hex');

        await query(`
            UPDATE users 
            SET email = $1, email_verified = false, email_verification_token = $2,
                account_tier = 'email', upgraded_to_email_at = NOW()
            WHERE id = $3 AND account_tier = 'anonymous'
        `, [email, verificationToken, userId]);

        // TODO: Send verification email (implement in Phase 2)
        // For MVP, we'll auto-verify
        await query(`
            UPDATE users 
            SET email_verified = true
            WHERE id = $1
        `, [userId]);

        return {
            success: true,
            verificationRequired: false, // Will be true when email service added
        };
    }

    /**
     * Upgrade to Tier 3 (social authentication)
     */
    async upgradeToSocial(
        userId: string,
        provider: 'google' | 'apple',
        socialId: string,
        socialEmail: string
    ): Promise<{ success: boolean }> {
        // Check if social account already linked
        const existing = await query(`
            SELECT id FROM users 
            WHERE auth_provider = $1 AND social_id = $2 AND id != $3
        `, [provider, socialId, userId]);

        if (existing.rows.length > 0) {
            throw new Error('This social account is already linked to another Iwanna account');
        }

        await query(`
            UPDATE users 
            SET auth_provider = $1, social_id = $2, social_email = $3,
                account_tier = 'authenticated', upgraded_to_authenticated_at = NOW()
            WHERE id = $4
        `, [provider, socialId, socialEmail, userId]);

        return { success: true };
    }

    /**
     * Check rate limits for wanna creation
     */
    async checkRateLimit(userId: string): Promise<{ allowed: boolean; remaining: number }> {
        const user = await query(`
            SELECT account_tier, wannas_today, rate_limit_reset_at
            FROM users 
            WHERE id = $1
        `, [userId]);

        if (user.rows.length === 0) {
            throw new Error('User not found');
        }

        const userData = user.rows[0];

        // Get tier limits
        const limits = {
            anonymous: parseInt(process.env.TIER1_WANNAS_PER_DAY || '5'),
            email: parseInt(process.env.TIER2_WANNAS_PER_DAY || '10'),
            authenticated: parseInt(process.env.TIER3_WANNAS_PER_DAY || '999'),
        };

        const limit = limits[userData.account_tier as keyof typeof limits];

        // Reset counter if new day
        const now = new Date();
        const resetTime = userData.rate_limit_reset_at;

        if (!resetTime || resetTime < now) {
            await query(`
                UPDATE users 
                SET wannas_today = 0, rate_limit_reset_at = $1
                WHERE id = $2
            `, [new Date(now.getTime() + 24 * 60 * 60 * 1000), userId]);

            return { allowed: true, remaining: limit - 1 };
        }

        // Check limit
        if (userData.wannas_today >= limit) {
            return { allowed: false, remaining: 0 };
        }

        return {
            allowed: true,
            remaining: limit - userData.wannas_today - 1,
        };
    }

    /**
     * Increment wanna counter
     */
    async incrementWannaCount(userId: string): Promise<void> {
        await query(`
            UPDATE users 
            SET wannas_today = wannas_today + 1, 
                wannas_created_count = wannas_created_count + 1,
                last_wanna_at = NOW()
            WHERE id = $1
        `, [userId]);
    }

    /**
     * Get user profile
     */
    async getUserProfile(userId: string): Promise<any> {
        const user = await query(`
            SELECT id, username, account_tier, trust_score, 
                   wannas_created_count, pods_joined_count, connections_made_count,
                   created_at
            FROM users 
            WHERE id = $1 AND is_banned = false
        `, [userId]);

        if (user.rows.length === 0) {
            throw new Error('User not found');
        }

        return user.rows[0];
    }
}

export const authService = new AuthService();
