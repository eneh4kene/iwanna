// Location Service for Reverse Geocoding
// Phase 1C: Wanna Creation & AI Intent Parsing

import axios from 'axios';

export interface LocationContext {
    city: string;
    neighborhood: string;
    country: string;
    formatted: string;
}

class LocationService {
    /**
     * Reverse geocode coordinates to human-readable location
     * Using OpenStreetMap Nominatim (free, no API key needed)
     */
    async reverseGeocode(
        latitude: number,
        longitude: number
    ): Promise<LocationContext | null> {
        try {
            const response = await axios.get(
                'https://nominatim.openstreetmap.org/reverse',
                {
                    params: {
                        lat: latitude,
                        lon: longitude,
                        format: 'json',
                        addressdetails: 1,
                    },
                    headers: {
                        'User-Agent': 'Iwanna/1.0', // Required by Nominatim
                    },
                }
            );

            const data = response.data;
            const address = data.address || {};

            return {
                city: address.city || address.town || address.village || 'Unknown',
                neighborhood: address.neighbourhood || address.suburb || address.city_district || '',
                country: address.country || '',
                formatted: data.display_name || '',
            };
        } catch (error) {
            console.error('Reverse geocoding error:', error);
            return null;
        }
    }

    /**
     * Calculate if location is within a reasonable area for the app
     * (Basic spam prevention - wannas should be from real locations)
     */
    isValidLocation(latitude: number, longitude: number): boolean {
        // Check if coordinates are within valid ranges
        if (latitude < -90 || latitude > 90) return false;
        if (longitude < -180 || longitude > 180) return false;

        // Check if not null island (0, 0)
        if (latitude === 0 && longitude === 0) return false;

        return true;
    }

    /**
     * Calculate distance between two points in miles
     */
    calculateDistance(
        lat1: number,
        lng1: number,
        lat2: number,
        lng2: number
    ): number {
        const R = 3959; // Earth's radius in miles
        const dLat = this.toRadians(lat2 - lat1);
        const dLng = this.toRadians(lng2 - lng1);

        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);

        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    /**
     * Convert degrees to radians
     */
    private toRadians(degrees: number): number {
        return degrees * (Math.PI / 180);
    }

    /**
     * Get a friendly location name for display
     */
    getFriendlyLocationName(locationContext: LocationContext | null): string {
        if (!locationContext) return 'your area';

        if (locationContext.neighborhood && locationContext.city) {
            return `${locationContext.neighborhood}, ${locationContext.city}`;
        } else if (locationContext.city) {
            return locationContext.city;
        } else {
            return 'your area';
        }
    }
}

export const locationService = new LocationService();
