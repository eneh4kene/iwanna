import { Pool, PoolClient } from 'pg';
import { dbConfig } from '../config';
import { logger } from '../utils/logger';
import type { DatabaseQuery, QueryResult } from '../types';

// Database connection pool
let pool: Pool | null = null;

// Initialize database connection
export const connectDatabase = async (): Promise<void> => {
  try {
    pool = new Pool(dbConfig);

    // Test the connection
    const client = await pool.connect();
    await client.query('SELECT NOW()');
    client.release();

    logger.info('Database connection established');
  } catch (error) {
    logger.error('Failed to connect to database:', error);
    throw error;
  }
};

// Get database connection
export const getDatabase = (): Pool => {
  if (!pool) {
    throw new Error('Database not initialized. Call connectDatabase() first.');
  }
  return pool;
};

// Execute a query
export const query = async <T = unknown>(
  text: string,
  values?: unknown[]
): Promise<QueryResult<T>> => {
  const db = getDatabase();
  const start = Date.now();

  try {
    const result = await db.query(text, values);
    const duration = Date.now() - start;

    logger.debug('Executed query', {
      text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
      duration: `${duration}ms`,
      rows: result.rowCount,
    });

    return result;
  } catch (error) {
    logger.error('Database query failed:', {
      text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
      error: error instanceof Error ? error.message : 'Unknown error',
    });
    throw error;
  }
};

// Execute a transaction
export const transaction = async <T>(
  callback: (client: PoolClient) => Promise<T>
): Promise<T> => {
  const db = getDatabase();
  const client = await db.connect();

  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

// Close database connection
export const closeDatabase = async (): Promise<void> => {
  if (pool) {
    await pool.end();
    pool = null;
    logger.info('Database connection closed');
  }
};

// Database schema creation
export const createSchema = async (): Promise<void> => {
  const db = getDatabase();

  try {
    // Enable PostGIS extension for geospatial queries
    await db.query('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
    await db.query('CREATE EXTENSION IF NOT EXISTS "postgis"');

    // Create users table
    await db.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        phone_number VARCHAR(20) UNIQUE NOT NULL,
        name VARCHAR(100) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        last_active TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        preferences JSONB DEFAULT '{
          "notifications": {"push": true, "email": false, "sms": true},
          "privacy": {"share_location": true, "show_last_active": true},
          "comfort": {"max_distance": 5, "preferred_group_size": 3, "energy_level": "medium"}
        }',
        status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'deleted'))
      )
    `);

    // Create wannas table
    await db.query(`
      CREATE TABLE IF NOT EXISTS wannas (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        raw_input TEXT NOT NULL,
        intent JSONB NOT NULL,
        embedding VECTOR(1536),
        location GEOGRAPHY(POINT, 4326) NOT NULL,
        mood_tag VARCHAR(20),
        status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'matched', 'expired')),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL
      )
    `);

    // Create pods table
    await db.query(`
      CREATE TABLE IF NOT EXISTS pods (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        status VARCHAR(20) DEFAULT 'forming' CHECK (status IN ('forming', 'active', 'completed', 'expired')),
        vibe_summary TEXT,
        collective_intent JSONB,
        centroid_location GEOGRAPHY(POINT, 4326),
        suggested_venues JSONB DEFAULT '[]',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
        completed_at TIMESTAMP WITH TIME ZONE
      )
    `);

    // Create pod_members table
    await db.query(`
      CREATE TABLE IF NOT EXISTS pod_members (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        pod_id UUID NOT NULL REFERENCES pods(id) ON DELETE CASCADE,
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        wanna_id UUID NOT NULL REFERENCES wannas(id) ON DELETE CASCADE,
        joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'left', 'removed')),
        marked_complete BOOLEAN DEFAULT FALSE,
        UNIQUE(pod_id, user_id)
      )
    `);

    // Create chat_messages table
    await db.query(`
      CREATE TABLE IF NOT EXISTS chat_messages (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        pod_id UUID NOT NULL REFERENCES pods(id) ON DELETE CASCADE,
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        content TEXT NOT NULL,
        message_type VARCHAR(20) DEFAULT 'user' CHECK (message_type IN ('user', 'system', 'ai')),
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    // Create vibe_summaries table
    await db.query(`
      CREATE TABLE IF NOT EXISTS vibe_summaries (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        pod_id UUID NOT NULL REFERENCES pods(id) ON DELETE CASCADE,
        summary_text TEXT NOT NULL,
        connections_made INTEGER DEFAULT 0,
        generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    // Create indexes for performance
    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_users_phone_number ON users(phone_number);
      CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
      CREATE INDEX IF NOT EXISTS idx_users_last_active ON users(last_active);
    `);

    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_wannas_user_id ON wannas(user_id);
      CREATE INDEX IF NOT EXISTS idx_wannas_status ON wannas(status);
      CREATE INDEX IF NOT EXISTS idx_wannas_created_at ON wannas(created_at);
      CREATE INDEX IF NOT EXISTS idx_wannas_expires_at ON wannas(expires_at);
      CREATE INDEX IF NOT EXISTS idx_wannas_location ON wannas USING GIST(location);
      CREATE INDEX IF NOT EXISTS idx_wannas_embedding ON wannas USING ivfflat(embedding vector_cosine_ops);
    `);

    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_pods_status ON pods(status);
      CREATE INDEX IF NOT EXISTS idx_pods_created_at ON pods(created_at);
      CREATE INDEX IF NOT EXISTS idx_pods_expires_at ON pods(expires_at);
      CREATE INDEX IF NOT EXISTS idx_pods_centroid_location ON pods USING GIST(centroid_location);
    `);

    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_pod_members_pod_id ON pod_members(pod_id);
      CREATE INDEX IF NOT EXISTS idx_pod_members_user_id ON pod_members(user_id);
      CREATE INDEX IF NOT EXISTS idx_pod_members_status ON pod_members(status);
    `);

    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_chat_messages_pod_id ON chat_messages(pod_id);
      CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);
      CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON chat_messages(created_at);
    `);

    await db.query(`
      CREATE INDEX IF NOT EXISTS idx_vibe_summaries_user_id ON vibe_summaries(user_id);
      CREATE INDEX IF NOT EXISTS idx_vibe_summaries_pod_id ON vibe_summaries(pod_id);
      CREATE INDEX IF NOT EXISTS idx_vibe_summaries_generated_at ON vibe_summaries(generated_at);
    `);

    logger.info('Database schema created successfully');
  } catch (error) {
    logger.error('Failed to create database schema:', error);
    throw error;
  }
};

// Database health check
export const checkDatabaseHealth = async (): Promise<boolean> => {
  try {
    const result = await query('SELECT 1 as health');
    return result.rows.length > 0;
  } catch (error) {
    logger.error('Database health check failed:', error);
    return false;
  }
};

// Database object for ORM-like interface
export const db = {
  wannas: {
    create: async (data: any) => {
      const { id, user_id, raw_input, mood_emoji, intent, embedding, location, location_accuracy, location_name, status, expires_at } = data;
      const result = await query(
        `INSERT INTO wannas (id, user_id, raw_input, mood_emoji, intent, embedding, location, location_accuracy, location_name, status, expires_at)
                 VALUES ($1, $2, $3, $4, $5, $6, ST_GeogFromText($7), $8, $9, $10, $11)
                 RETURNING *`,
        [id, user_id, raw_input, mood_emoji, JSON.stringify(intent), embedding, location, location_accuracy, location_name, status, expires_at]
      );
      return result.rows[0];
    },
    findOne: async (options: { where: any }) => {
      const { where } = options;
      const conditions = Object.keys(where).map((key, index) => `${key} = $${index + 1}`).join(' AND ');
      const values = Object.values(where);
      const result = await query(`SELECT * FROM wannas WHERE ${conditions}`, values);
      return result.rows[0] || null;
    },
    findAll: async (options: { where?: any; order?: any }) => {
      const { where, order } = options;
      let queryStr = 'SELECT * FROM wannas';
      let values: any[] = [];

      if (where) {
        const conditions = Object.keys(where).map((key, index) => `${key} = $${index + 1}`).join(' AND ');
        values = Object.values(where);
        queryStr += ` WHERE ${conditions}`;
      }

      if (order) {
        const orderClause = order.map(([field, direction]: [string, string]) => `${field} ${direction}`).join(', ');
        queryStr += ` ORDER BY ${orderClause}`;
      }

      const result = await query(queryStr, values);
      return result.rows;
    },
    findByPk: async (id: string) => {
      const result = await query('SELECT * FROM wannas WHERE id = $1', [id]);
      return result.rows[0] || null;
    },
    update: async (data: any, options: { where: any }) => {
      const { where } = options;
      const setClause = Object.keys(data).map((key, index) => `${key} = $${index + 1}`).join(', ');
      const whereClause = Object.keys(where).map((key, index) => `${key} = $${Object.keys(data).length + index + 1}`).join(' AND ');
      const values = [...Object.values(data), ...Object.values(where)];

      const result = await query(
        `UPDATE wannas SET ${setClause} WHERE ${whereClause} RETURNING *`,
        values
      );
      return result.rows;
    },
  },
  users: {
    increment: async (field: string, options: { where: any }) => {
      const { where } = options;
      const whereClause = Object.keys(where).map((key, index) => `${key} = $${index + 1}`).join(' AND ');
      const values = Object.values(where);

      const result = await query(
        `UPDATE users SET ${field} = ${field} + 1 WHERE ${whereClause} RETURNING *`,
        values
      );
      return result.rows;
    },
    update: async (data: any, options: { where: any }) => {
      const { where } = options;
      const setClause = Object.keys(data).map((key, index) => `${key} = $${index + 1}`).join(', ');
      const whereClause = Object.keys(where).map((key, index) => `${key} = $${Object.keys(data).length + index + 1}`).join(' AND ');
      const values = [...Object.values(data), ...Object.values(where)];

      const result = await query(
        `UPDATE users SET ${setClause} WHERE ${whereClause} RETURNING *`,
        values
      );
      return result.rows;
    },
  },
};
