import { Server as SocketIOServer } from 'socket.io';
import { logger } from '../utils/logger';
import { realtime } from './redis';
import type { AuthenticatedSocket, WebSocketEventType } from '../types';

// WebSocket event handlers
export const setupWebSocket = (io: SocketIOServer): void => {
    // Authentication middleware
    io.use(async (socket: AuthenticatedSocket, next) => {
        try {
            // TODO: Implement JWT authentication
            // For now, allow all connections
            const userId = 'mock-user-id';
            socket.userId = userId;
            socket.user = { id: userId, phoneNumber: '+1234567890', name: 'Test User' } as any;

            logger.info('WebSocket connection authenticated', { userId });
            next();
        } catch (error) {
            logger.error('WebSocket authentication failed:', error);
            next(new Error('Authentication failed'));
        }
    });

    // Connection handler
    io.on('connection', async (socket: AuthenticatedSocket) => {
        const userId = socket.userId!;
        const socketId = socket.id;

        logger.info('WebSocket client connected', { userId, socketId });

        // Set user as active
        await realtime.setActiveUser(userId, socketId);

        // Join pod room
        socket.on('join_pod', async (data: { pod_id: string }) => {
            const { pod_id } = data;

            logger.info('User joining pod', { userId, podId: pod_id });

            // Join the pod room
            socket.join(`pod:${pod_id}`);

            // Add user to pod members in Redis
            await realtime.addPodMember(pod_id, userId);

            // Notify other pod members
            socket.to(`pod:${pod_id}`).emit('user_joined', {
                user_id: userId,
                pod_id: pod_id,
            });
        });

        // Leave pod room
        socket.on('leave_pod', async (data: { pod_id: string }) => {
            const { pod_id } = data;

            logger.info('User leaving pod', { userId, podId: pod_id });

            // Leave the pod room
            socket.leave(`pod:${pod_id}`);

            // Remove user from pod members in Redis
            await realtime.removePodMember(pod_id, userId);

            // Notify other pod members
            socket.to(`pod:${pod_id}`).emit('user_left', {
                user_id: userId,
                pod_id: pod_id,
            });
        });

        // Send message
        socket.on('send_message', async (data: { pod_id: string; content: string }) => {
            const { pod_id, content } = data;

            logger.info('Message sent', { userId, podId: pod_id, content });

            // TODO: Save message to database
            const message = {
                id: `msg_${Date.now()}`,
                pod_id,
                user_id: userId,
                content,
                message_type: 'user',
                created_at: new Date(),
            };

            // Broadcast message to pod room
            io.to(`pod:${pod_id}`).emit('new_message', { message });
        });

        // Typing indicator
        socket.on('typing', async (data: { pod_id: string; is_typing: boolean }) => {
            const { pod_id, is_typing } = data;

            if (is_typing) {
                await realtime.addTypingUser(pod_id, userId);
            } else {
                await realtime.removeTypingUser(pod_id, userId);
            }

            // Broadcast typing status to pod room
            socket.to(`pod:${pod_id}`).emit('user_typing', {
                user_id: userId,
                pod_id: pod_id,
                is_typing,
            });
        });

        // Location update
        socket.on('location_update', async (data: { location: { latitude: number; longitude: number } }) => {
            const { location } = data;

            logger.info('Location update received', { userId, location });

            // TODO: Update user location in database
            // Broadcast location to relevant pods
        });

        // Disconnect handler
        socket.on('disconnect', async (reason) => {
            logger.info('WebSocket client disconnected', { userId, socketId, reason });

            // Remove user from active users
            await realtime.removeActiveUser(userId);

            // TODO: Handle pod cleanup if user was in any pods
        });

        // Error handler
        socket.on('error', (error) => {
            logger.error('WebSocket error', { userId, socketId, error });
        });
    });

    // Broadcast functions for server-side events
    const broadcast = {
        // Pod formed
        podFormed: (podId: string, pod: any) => {
            logger.info('Broadcasting pod formed', { podId });
            io.emit('pod_formed', { pod });
        },

        // Match found
        matchFound: (podId: string, members: any[], vibeSummary: string) => {
            logger.info('Broadcasting match found', { podId });
            io.emit('match_found', { pod_id: podId, members, vibe_summary: vibeSummary });
        },

        // Pod expired
        podExpired: (podId: string, summary: string) => {
            logger.info('Broadcasting pod expired', { podId });
            io.to(`pod:${podId}`).emit('pod_expired', { pod_id: podId, summary });
        },

        // AI action response
        aiActionResponse: (podId: string, action: string, data: any) => {
            logger.info('Broadcasting AI action response', { podId, action });
            io.to(`pod:${podId}`).emit('ai_action_response', { action, data });
        },
    };

    // Export broadcast functions for use in other services
    (io as any).broadcast = broadcast;

    logger.info('WebSocket server configured successfully');
};
