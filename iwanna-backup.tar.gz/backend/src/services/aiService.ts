// AI Service for Intent Parsing and Embedding Generation
// Phase 1C: Wanna Creation & AI Intent Parsing

import OpenAI from 'openai';
import { aiConfig } from '../config';

// Initialize OpenAI client
const openai = new OpenAI({
    apiKey: aiConfig.openaiApiKey,
});

// Intent structure for AI parsing
export interface Intent {
    // What they want to do
    activity: string;                    // e.g., "coffee", "hiking", "brainstorming"
    category: string;                    // e.g., "food_social", "outdoors", "creative"

    // Social context
    energy_level: 'low' | 'medium' | 'high';
    social_preference: 'intimate' | 'small_group' | 'open';

    // Timing
    time_sensitivity: 'now' | 'today' | 'flexible';
    duration_estimate: number;           // Minutes (e.g., 60, 120, 180)

    // Location flexibility
    location_flexibility: 'specific' | 'neighborhood' | 'city_wide';
    venue_type?: string;                 // e.g., "cafe", "park", "bar"

    // Extracted keywords for matching
    keywords: string[];                  // e.g., ["coffee", "casual", "conversation"]

    // Emotional tone
    emotional_tone: string;              // e.g., "curious", "energetic", "relaxed"

    // AI confidence
    confidence: number;                  // 0-1 score
}

export interface ParseIntentResult {
    intent: Intent;
    embedding: number[];
}

export interface LocationContext {
    city: string;
    neighborhood: string;
    country: string;
    formatted: string;
}

class AIService {
    /**
     * Parse user's wanna text into structured intent
     */
    async parseIntent(
        rawInput: string,
        moodEmoji?: string,
        locationContext?: LocationContext
    ): Promise<ParseIntentResult> {
        // Build context-aware prompt
        const systemPrompt = `You are an intent parser for Iwanna, a social connection app.
Users express what they want to do right now to meet 2-4 people nearby.

Parse their input into structured JSON with these fields:
- activity: Main activity (lowercase, 1-3 words)
- category: One of: food_social, outdoors, creative, sports, conversation, entertainment, nightlife
- energy_level: low, medium, or high
- social_preference: intimate (2-3 people), small_group (3-5), open (flexible)
- time_sensitivity: now (within 1-2 hours), today (within 6 hours), flexible
- duration_estimate: Estimated minutes (30, 60, 90, 120, 180, 240)
- location_flexibility: specific (exact venue), neighborhood (within 1 mile), city_wide (anywhere)
- venue_type: Type of place if clear (cafe, bar, park, restaurant, gym, etc.)
- keywords: Array of 3-7 relevant matching keywords
- emotional_tone: One word describing the vibe (curious, energetic, relaxed, adventurous, etc.)
- confidence: 0-1 score of how confident you are in this parsing

Be conversational and natural. Interpret casual language. Default to medium energy and small_group if unclear.`;

        const userPrompt = `Input: "${rawInput}"
${moodEmoji ? `Mood: ${moodEmoji}` : ''}
${locationContext ? `Location context: ${locationContext.neighborhood}, ${locationContext.city}` : ''}

Parse this into structured intent JSON.`;

        try {
            const completion = await openai.chat.completions.create({
                model: aiConfig.openaiModel,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userPrompt }
                ],
                response_format: { type: 'json_object' },
                temperature: 0.3,
            });

            const intentData = JSON.parse(completion.choices[0]?.message?.content || '{}');

            // Generate embedding for semantic matching
            const embedding = await this.generateEmbedding(rawInput);

            return {
                intent: intentData as Intent,
                embedding,
            };
        } catch (error) {
            console.error('AI parsing error:', error);

            // Fallback to basic parsing if AI fails
            return this.basicFallbackParsing(rawInput, moodEmoji);
        }
    }

    /**
     * Generate semantic embedding for similarity matching
     */
    async generateEmbedding(text: string): Promise<number[]> {
        try {
            const response = await openai.embeddings.create({
                model: aiConfig.openaiEmbeddingModel,
                input: text,
                dimensions: 1536,
            });

            return response.data[0]?.embedding || [];
        } catch (error) {
            console.error('Embedding generation error:', error);
            // Return zero vector as fallback
            return new Array(1536).fill(0);
        }
    }

    /**
     * Fallback parsing if AI fails (keyword-based)
     */
    private basicFallbackParsing(
        rawInput: string,
        _moodEmoji?: string
    ): ParseIntentResult {
        const lower = rawInput.toLowerCase();

        // Simple keyword detection
        let activity = 'hang out';
        let category = 'conversation';
        let venue_type = undefined;

        if (lower.includes('coffee') || lower.includes('cafe')) {
            activity = 'coffee';
            category = 'food_social';
            venue_type = 'cafe';
        } else if (lower.includes('drink') || lower.includes('bar')) {
            activity = 'drinks';
            category = 'nightlife';
            venue_type = 'bar';
        } else if (lower.includes('food') || lower.includes('eat')) {
            activity = 'food';
            category = 'food_social';
            venue_type = 'restaurant';
        } else if (lower.includes('walk') || lower.includes('hike')) {
            activity = 'walk';
            category = 'outdoors';
            venue_type = 'park';
        } else if (lower.includes('work') || lower.includes('study')) {
            activity = 'cowork';
            category = 'conversation';
            venue_type = 'cafe';
        }

        const keywords = rawInput
            .toLowerCase()
            .split(/\s+/)
            .filter(word => word.length > 3);

        const intent: Intent = {
            activity,
            category,
            energy_level: 'medium',
            social_preference: 'small_group',
            time_sensitivity: 'now',
            duration_estimate: 120,
            location_flexibility: 'neighborhood',
            venue_type,
            keywords: keywords.slice(0, 7),
            emotional_tone: 'curious',
            confidence: 0.5, // Low confidence for fallback
        };

        return {
            intent,
            embedding: new Array(1536).fill(0), // Zero vector
        };
    }

    /**
     * Get suggestions for similar wannas (for UI autocomplete)
     */
    async getSuggestions(partialInput: string): Promise<string[]> {
        const commonWannas = [
            'I wanna grab coffee and chat',
            'I wanna go for a walk',
            'I wanna grab drinks',
            'I wanna explore the city',
            'I wanna brainstorm startup ideas',
            'I wanna play basketball',
            'I wanna try a new restaurant',
            'I wanna study together',
            'I wanna go to a museum',
            'I wanna watch the sunset',
        ];

        // Simple filter for MVP
        return commonWannas
            .filter(w => w.toLowerCase().includes(partialInput.toLowerCase()))
            .slice(0, 5);
    }
}

export const aiService = new AIService();
