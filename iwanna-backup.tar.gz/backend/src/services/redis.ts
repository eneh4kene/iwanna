import Redis from 'ioredis';
import { redisConfig } from '../config';
import { logger } from '../utils/logger';

// Redis client instance
let redis: Redis | null = null;

// Initialize Redis connection
export const connectRedis = async (): Promise<void> => {
    try {
        redis = new Redis(redisConfig);

        // Test the connection
        await redis.ping();

        logger.info('Redis connection established');
    } catch (error) {
        logger.error('Failed to connect to Redis:', error);
        throw error;
    }
};

// Get Redis client
export const getRedis = (): Redis => {
    if (!redis) {
        throw new Error('Redis not initialized. Call connectRedis() first.');
    }
    return redis;
};

// Close Redis connection
export const closeRedis = async (): Promise<void> => {
    if (redis) {
        await redis.quit();
        redis = null;
        logger.info('Redis connection closed');
    }
};

// Redis health check
export const checkRedisHealth = async (): Promise<boolean> => {
    try {
        const result = await getRedis().ping();
        return result === 'PONG';
    } catch (error) {
        logger.error('Redis health check failed:', error);
        return false;
    }
};

// Cache utilities
export const cache = {
    // Set a key-value pair with TTL
    async set(key: string, value: string | object, ttlSeconds?: number): Promise<void> {
        const redis = getRedis();
        const serializedValue = typeof value === 'string' ? value : JSON.stringify(value);

        if (ttlSeconds) {
            await redis.setex(key, ttlSeconds, serializedValue);
        } else {
            await redis.set(key, serializedValue);
        }
    },

    // Get a value by key
    async get<T = string>(key: string): Promise<T | null> {
        const redis = getRedis();
        const value = await redis.get(key);

        if (value === null) return null;

        try {
            return JSON.parse(value) as T;
        } catch {
            return value as T;
        }
    },

    // Delete a key
    async del(key: string): Promise<number> {
        const redis = getRedis();
        return await redis.del(key);
    },

    // Check if key exists
    async exists(key: string): Promise<boolean> {
        const redis = getRedis();
        const result = await redis.exists(key);
        return result === 1;
    },

    // Set expiration for a key
    async expire(key: string, ttlSeconds: number): Promise<boolean> {
        const redis = getRedis();
        const result = await redis.expire(key, ttlSeconds);
        return result === 1;
    },

    // Get TTL for a key
    async ttl(key: string): Promise<number> {
        const redis = getRedis();
        return await redis.ttl(key);
    },

    // Increment a counter
    async incr(key: string): Promise<number> {
        const redis = getRedis();
        return await redis.incr(key);
    },

    // Decrement a counter
    async decr(key: string): Promise<number> {
        const redis = getRedis();
        return await redis.decr(key);
    },

    // Add to a set
    async sadd(key: string, ...members: string[]): Promise<number> {
        const redis = getRedis();
        return await redis.sadd(key, ...members);
    },

    // Remove from a set
    async srem(key: string, ...members: string[]): Promise<number> {
        const redis = getRedis();
        return await redis.srem(key, ...members);
    },

    // Get all members of a set
    async smembers(key: string): Promise<string[]> {
        const redis = getRedis();
        return await redis.smembers(key);
    },

    // Check if member is in set
    async sismember(key: string, member: string): Promise<boolean> {
        const redis = getRedis();
        const result = await redis.sismember(key, member);
        return result === 1;
    },

    // Add to a sorted set
    async zadd(key: string, score: number, member: string): Promise<number> {
        const redis = getRedis();
        return await redis.zadd(key, score, member);
    },

    // Get range from sorted set
    async zrange(key: string, start: number, stop: number): Promise<string[]> {
        const redis = getRedis();
        return await redis.zrange(key, start, stop);
    },

    // Get range with scores from sorted set
    async zrangeWithScores(key: string, start: number, stop: number): Promise<Array<{ score: number; member: string }>> {
        const redis = getRedis();
        const result = await redis.zrange(key, start, stop, 'WITHSCORES');
        const pairs: Array<{ score: number; member: string }> = [];

        for (let i = 0; i < result.length; i += 2) {
            pairs.push({
                member: result[i],
                score: parseFloat(result[i + 1]),
            });
        }

        return pairs;
    },

    // Remove from sorted set
    async zrem(key: string, ...members: string[]): Promise<number> {
        const redis = getRedis();
        return await redis.zrem(key, ...members);
    },

    // Get count of sorted set
    async zcard(key: string): Promise<number> {
        const redis = getRedis();
        return await redis.zcard(key);
    },

    // Publish to a channel
    async publish(channel: string, message: string): Promise<number> {
        const redis = getRedis();
        return await redis.publish(channel, message);
    },

    // Subscribe to channels
    async subscribe(channels: string[], callback: (channel: string, message: string) => void): Promise<void> {
        const redis = getRedis();
        const subscriber = redis.duplicate();

        await subscriber.subscribe(...channels);

        subscriber.on('message', (channel, message) => {
            callback(channel, message);
        });
    },
};

// Session management
export const sessions = {
    // Create a session
    async create(userId: string, sessionData: object, ttlSeconds: number = 3600): Promise<string> {
        const sessionId = `session:${userId}:${Date.now()}`;
        await cache.set(sessionId, sessionData, ttlSeconds);
        return sessionId;
    },

    // Get session data
    async get(sessionId: string): Promise<object | null> {
        return await cache.get(sessionId);
    },

    // Update session
    async update(sessionId: string, sessionData: object, ttlSeconds?: number): Promise<void> {
        await cache.set(sessionId, sessionData, ttlSeconds);
    },

    // Delete session
    async delete(sessionId: string): Promise<void> {
        await cache.del(sessionId);
    },

    // Extend session TTL
    async extend(sessionId: string, ttlSeconds: number): Promise<boolean> {
        return await cache.expire(sessionId, ttlSeconds);
    },
};

// Rate limiting
export const rateLimit = {
    // Check if request is within rate limit
    async check(key: string, limit: number, windowSeconds: number): Promise<{ allowed: boolean; remaining: number; resetTime: number }> {
        const redis = getRedis();
        const window = Math.floor(Date.now() / 1000 / windowSeconds);
        const rateLimitKey = `rate_limit:${key}:${window}`;

        const current = await redis.incr(rateLimitKey);

        if (current === 1) {
            await redis.expire(rateLimitKey, windowSeconds);
        }

        const remaining = Math.max(0, limit - current);
        const resetTime = (window + 1) * windowSeconds * 1000;

        return {
            allowed: current <= limit,
            remaining,
            resetTime,
        };
    },

    // Reset rate limit for a key
    async reset(key: string): Promise<void> {
        const redis = getRedis();
        const pattern = `rate_limit:${key}:*`;
        const keys = await redis.keys(pattern);

        if (keys.length > 0) {
            await redis.del(...keys);
        }
    },
};

// Real-time features
export const realtime = {
    // Store active user
    async setActiveUser(userId: string, socketId: string, ttlSeconds: number = 300): Promise<void> {
        const key = `active_user:${userId}`;
        await cache.set(key, { socketId, lastSeen: Date.now() }, ttlSeconds);
    },

    // Get active user
    async getActiveUser(userId: string): Promise<{ socketId: string; lastSeen: number } | null> {
        const key = `active_user:${userId}`;
        return await cache.get(key);
    },

    // Remove active user
    async removeActiveUser(userId: string): Promise<void> {
        const key = `active_user:${userId}`;
        await cache.del(key);
    },

    // Store pod members
    async setPodMembers(podId: string, userIds: string[], ttlSeconds: number = 10800): Promise<void> {
        const key = `pod_members:${podId}`;
        await cache.set(key, userIds, ttlSeconds);
    },

    // Get pod members
    async getPodMembers(podId: string): Promise<string[]> {
        const key = `pod_members:${podId}`;
        return await cache.get(key) || [];
    },

    // Add user to pod
    async addPodMember(podId: string, userId: string): Promise<void> {
        const key = `pod_members:${podId}`;
        const members = await cache.get<string[]>(key) || [];

        if (!members.includes(userId)) {
            members.push(userId);
            await cache.set(key, members, 10800); // 3 hours
        }
    },

    // Remove user from pod
    async removePodMember(podId: string, userId: string): Promise<void> {
        const key = `pod_members:${podId}`;
        const members = await cache.get<string[]>(key) || [];
        const filteredMembers = members.filter(id => id !== userId);

        await cache.set(key, filteredMembers, 10800);
    },

    // Store typing users
    async setTypingUsers(podId: string, userIds: string[], ttlSeconds: number = 30): Promise<void> {
        const key = `typing:${podId}`;
        await cache.set(key, userIds, ttlSeconds);
    },

    // Get typing users
    async getTypingUsers(podId: string): Promise<string[]> {
        const key = `typing:${podId}`;
        return await cache.get(key) || [];
    },

    // Add typing user
    async addTypingUser(podId: string, userId: string): Promise<void> {
        const key = `typing:${podId}`;
        const typingUsers = await cache.get<string[]>(key) || [];

        if (!typingUsers.includes(userId)) {
            typingUsers.push(userId);
            await cache.set(key, typingUsers, 30);
        }
    },

    // Remove typing user
    async removeTypingUser(podId: string, userId: string): Promise<void> {
        const key = `typing:${podId}`;
        const typingUsers = await cache.get<string[]>(key) || [];
        const filteredUsers = typingUsers.filter(id => id !== userId);

        await cache.set(key, filteredUsers, 30);
    },
};

// Export redis instance for direct access
export { redis };
