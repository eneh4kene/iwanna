import express from 'express';
import cors from 'cors';
import { createServer } from 'http';

const app = express();
const server = createServer(app);

// Basic middleware
app.use(cors({
    origin: ['http://localhost:8081', 'http://localhost:19006'],
    credentials: true,
}));

app.use(express.json());

// Health check
app.get('/health', (_req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: 'development',
        version: '1.0.0',
    });
});

// API routes
app.get('/api/v1/health', (_req, res) => {
    res.json({
        success: true,
        message: 'Iwanna API is healthy',
        timestamp: new Date().toISOString(),
    });
});

// Mock auth endpoints
app.post('/api/v1/auth/send-code', (_req, res) => {
    res.json({
        success: true,
        data: { message: 'Verification code sent' },
    });
});

app.post('/api/v1/auth/verify-code', (_req, res) => {
    res.json({
        success: true,
        data: {
            user: { id: 'mock-user-id', phoneNumber: '+1234567890', name: 'Test User' },
            tokens: { accessToken: 'mock-token', refreshToken: 'mock-refresh' },
        },
    });
});

app.get('/api/v1/auth/me', (_req, res) => {
    res.json({
        success: true,
        data: { id: 'mock-user-id', phoneNumber: '+1234567890', name: 'Test User' },
    });
});

// Mock wanna endpoints
app.post('/api/v1/wannas', (req, res) => {
    res.json({
        success: true,
        data: { id: 'mock-wanna-id', text: req.body.text, mood: req.body.mood },
    });
});

app.get('/api/v1/wannas/active', (_req, res) => {
    res.json({
        success: true,
        data: [],
    });
});

// Mock pod endpoints
app.get('/api/v1/pods/active', (_req, res) => {
    res.json({
        success: true,
        data: [],
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: {
            code: 'NOT_FOUND',
            message: `Route ${req.method} ${req.originalUrl} not found`,
        },
    });
});

// Start server
const PORT = process.env['PORT'] || 3001;

server.listen(PORT, () => {
    console.log(`🌟 Iwanna backend server running on port ${PORT}`);
    console.log(`📱 Environment: development`);
    console.log(`🔗 API URL: http://localhost:${PORT}/api/v1`);
    console.log('🚀 Ready to connect people through moments of impulse!');
});

export { app, server };
