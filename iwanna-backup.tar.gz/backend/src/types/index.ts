// Backend Types for Iwanna API
// All types must be strict and explicit - no 'any' types allowed

import { Request } from 'express';
import { Socket } from 'socket.io';

// User types
export interface User {
    id: string;
    phone_number: string;
    name: string;
    created_at: Date;
    last_active: Date;
    preferences: UserPreferences;
    status: UserStatus;
}

export interface UserPreferences {
    notifications: {
        push: boolean;
        email: boolean;
        sms: boolean;
    };
    privacy: {
        share_location: boolean;
        show_last_active: boolean;
    };
    comfort: {
        max_distance: number; // in miles
        preferred_group_size: number;
        energy_level: EnergyLevel;
    };
}

export type UserStatus = 'active' | 'suspended' | 'deleted';
export type EnergyLevel = 'low' | 'medium' | 'high';

// Wanna types
export interface Wanna {
    id: string;
    user_id: string;
    raw_input: string;
    intent: WannaIntent;
    embedding: number[]; // Vector embedding for semantic matching
    location: Location;
    mood_tag?: string;
    status: WannaStatus;
    created_at: Date;
    expires_at: Date;
}

export interface WannaIntent {
    activity: string;
    category: ActivityCategory;
    energy_level: EnergyLevel;
    social_preference: SocialPreference;
    time_sensitivity: TimeSensitivity;
    location_flexibility: LocationFlexibility;
    vibe_keywords: string[];
    emotional_tone: EmotionalTone;
}

export type ActivityCategory =
    | 'food_social'
    | 'creative'
    | 'fitness'
    | 'learning'
    | 'entertainment'
    | 'work'
    | 'relaxation'
    | 'adventure'
    | 'other';

export type SocialPreference = 'solo' | 'small_group' | 'large_group' | 'any';
export type TimeSensitivity = 'now' | 'soon' | 'flexible';
export type LocationFlexibility = 'specific' | 'neighborhood' | 'city' | 'any';
export type EmotionalTone = 'curious' | 'excited' | 'relaxed' | 'energetic' | 'contemplative';
export type WannaStatus = 'active' | 'matched' | 'expired';

// Pod types
export interface Pod {
    id: string;
    status: PodStatus;
    vibe_summary: string;
    collective_intent: CollectiveIntent;
    centroid_location: Location;
    suggested_venues: Venue[];
    created_at: Date;
    expires_at: Date;
    completed_at?: Date;
}

export interface CollectiveIntent {
    primary_activity: string;
    energy_level: EnergyLevel;
    vibe_keywords: string[];
    group_size: number;
    estimated_duration: number; // in minutes
}

export type PodStatus = 'forming' | 'active' | 'completed' | 'expired';

// Pod member types
export interface PodMember {
    id: string;
    pod_id: string;
    user_id: string;
    wanna_id: string;
    joined_at: Date;
    status: PodMemberStatus;
    marked_complete: boolean;
}

export type PodMemberStatus = 'active' | 'left' | 'removed';

// Chat types
export interface ChatMessage {
    id: string;
    pod_id: string;
    user_id: string;
    content: string;
    message_type: MessageType;
    metadata?: MessageMetadata;
    created_at: Date;
}

export type MessageType = 'user' | 'system' | 'ai';

export interface MessageMetadata {
    actions?: ChatAction[];
    location_data?: Location;
    ai_context?: string;
}

export interface ChatAction {
    type: 'suggest_venue' | 'icebreaker' | 'location_share' | 'pod_complete';
    data: Record<string, unknown>;
}

// Vibe summary types
export interface VibeSummary {
    id: string;
    user_id: string;
    pod_id: string;
    summary_text: string;
    connections_made: number;
    generated_at: Date;
}

// Location types
export interface Location {
    latitude: number;
    longitude: number;
    address?: string;
    city?: string;
    state?: string;
    country?: string;
}

// Venue types
export interface Venue {
    id: string;
    name: string;
    location: Location;
    category: string;
    rating?: number;
    price_level?: number;
    distance?: number; // in miles
    description?: string;
}

// API Response types
export interface ApiResponse<T = unknown> {
    success: boolean;
    data?: T;
    error?: ApiError;
    message?: string;
}

export interface ApiError {
    code: string;
    message: string;
    details?: Record<string, unknown>;
}

// Authentication types
export interface AuthTokens {
    access_token: string;
    refresh_token: string;
    expires_at: Date;
}

export interface JWTPayload {
    user_id: string;
    phone_number: string;
    type: 'access' | 'refresh';
    iat: number;
    exp: number;
}

// Request types with authentication
export interface AuthenticatedRequest extends Request {
    user?: User;
    tokens?: AuthTokens;
}

// WebSocket types
export interface AuthenticatedSocket extends Socket {
    user?: User;
    userId?: string;
}

// WebSocket event types
export interface WebSocketEvent {
    type: WebSocketEventType;
    data: unknown;
    timestamp: Date;
}

export type WebSocketEventType =
    | 'pod_formed'
    | 'match_found'
    | 'new_message'
    | 'user_joined'
    | 'user_left'
    | 'user_typing'
    | 'pod_expired'
    | 'ai_action_response'
    | 'location_update';

// Database query types
export interface DatabaseQuery {
    text: string;
    values: unknown[];
}

export interface QueryResult<T = unknown> {
    rows: T[];
    rowCount: number;
}

// Matching algorithm types
export interface MatchingCandidate {
    user_id: string;
    wanna_id: string;
    score: number;
    reasons: string[];
}

export interface MatchingResult {
    candidates: MatchingCandidate[];
    pod_formed: boolean;
    pod_id?: string;
}

// AI service types
export interface IntentParsingResult {
    activity: string;
    category: ActivityCategory;
    energy_level: EnergyLevel;
    social_preference: SocialPreference;
    time_sensitivity: TimeSensitivity;
    location_flexibility: LocationFlexibility;
    vibe_keywords: string[];
    emotional_tone: EmotionalTone;
    confidence: number;
}

export interface VibeSummaryResult {
    summary_text: string;
    connections_made: number;
    key_moments: string[];
    overall_energy: EnergyLevel;
}

// Form validation types
export interface CreateWannaRequest {
    text: string;
    mood?: string;
    location: Location;
}

export interface AuthRequest {
    phone_number: string;
    verification_code?: string;
}

// Error types
export class IwannaError extends Error {
    constructor(
        message: string,
        public code: string,
        public statusCode: number = 500,
        public details?: Record<string, unknown>
    ) {
        super(message);
        this.name = 'IwannaError';
    }
}

export class ValidationError extends IwannaError {
    constructor(message: string, details?: Record<string, unknown>) {
        super(message, 'VALIDATION_ERROR', 400, details);
        this.name = 'ValidationError';
    }
}

export class AuthenticationError extends IwannaError {
    constructor(message: string = 'Authentication required') {
        super(message, 'AUTH_ERROR', 401);
        this.name = 'AuthenticationError';
    }
}

export class AuthorizationError extends IwannaError {
    constructor(message: string = 'Insufficient permissions') {
        super(message, 'AUTHORIZATION_ERROR', 403);
        this.name = 'AuthorizationError';
    }
}

export class NotFoundError extends IwannaError {
    constructor(resource: string = 'Resource') {
        super(`${resource} not found`, 'NOT_FOUND', 404);
        this.name = 'NotFoundError';
    }
}

export class ConflictError extends IwannaError {
    constructor(message: string) {
        super(message, 'CONFLICT', 409);
        this.name = 'ConflictError';
    }
}

export class RateLimitError extends IwannaError {
    constructor(message: string = 'Rate limit exceeded') {
        super(message, 'RATE_LIMIT', 429);
        this.name = 'RateLimitError';
    }
}

export class DatabaseError extends IwannaError {
    constructor(message: string, details?: Record<string, unknown>) {
        super(message, 'DATABASE_ERROR', 500, details);
        this.name = 'DatabaseError';
    }
}

export class ExternalServiceError extends IwannaError {
    constructor(service: string, message: string, details?: Record<string, unknown>) {
        super(`${service} service error: ${message}`, 'EXTERNAL_SERVICE_ERROR', 502, details);
        this.name = 'ExternalServiceError';
    }
}

// Utility types
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

// Environment types
export interface EnvironmentConfig {
    nodeEnv: 'development' | 'staging' | 'production';
    port: number;
    databaseUrl: string;
    redisUrl: string;
    jwtSecret: string;
    corsOrigins: string[];
}

// Logging types
export interface LogContext {
    userId?: string;
    requestId?: string;
    ip?: string;
    userAgent?: string;
    method?: string;
    url?: string;
    statusCode?: number;
    responseTime?: number;
    error?: Error;
}

// Cache types
export interface CacheOptions {
    ttl?: number; // Time to live in seconds
    key?: string;
    tags?: string[];
}

// Job types
export interface JobData {
    type: string;
    payload: Record<string, unknown>;
    priority?: number;
    delay?: number;
    attempts?: number;
}

export interface JobResult {
    success: boolean;
    data?: unknown;
    error?: string;
}
