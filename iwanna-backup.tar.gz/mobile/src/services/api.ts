import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';
import type {
    ApiResponse,
    AuthTokens,
    User,
    Wanna,
    Pod,
    ChatMessage,
    VibeSummary,
    CreateWannaInput,
    CreateAccountForm,
    RecoverAccountForm,
    DeviceInfo,
} from '../types';

// API Configuration
const API_BASE_URL = Constants.expoConfig?.extra?.apiUrl || 'http://localhost:3001/api/v1';
const WS_BASE_URL = Constants.expoConfig?.extra?.wsUrl || 'http://localhost:3001';

// Token management
const TOKEN_KEY = 'iwanna_auth_tokens';

class ApiService {
    private baseUrl: string;
    private wsUrl: string;

    constructor() {
        this.baseUrl = API_BASE_URL;
        this.wsUrl = WS_BASE_URL;
    }

    // Token management
    private async getTokens(): Promise<AuthTokens | null> {
        try {
            const tokensJson = await SecureStore.getItemAsync(TOKEN_KEY);
            if (!tokensJson) return null;

            const tokens = JSON.parse(tokensJson) as AuthTokens;
            // Check if tokens are expired
            if (new Date(tokens.expiresAt) <= new Date()) {
                await this.clearTokens();
                return null;
            }

            return tokens;
        } catch (error) {
            console.error('Error getting tokens:', error);
            return null;
        }
    }

    private async setTokens(tokens: AuthTokens): Promise<void> {
        try {
            await SecureStore.setItemAsync(TOKEN_KEY, JSON.stringify(tokens));
        } catch (error) {
            console.error('Error setting tokens:', error);
        }
    }

    private async clearTokens(): Promise<void> {
        try {
            await SecureStore.deleteItemAsync(TOKEN_KEY);
        } catch (error) {
            console.error('Error clearing tokens:', error);
        }
    }

    // HTTP request helper
    private async request<T>(
        endpoint: string,
        options: RequestInit = {}
    ): Promise<ApiResponse<T>> {
        try {
            const tokens = await this.getTokens();
            const url = `${this.baseUrl}${endpoint}`;

            const headers: HeadersInit = {
                'Content-Type': 'application/json',
                ...options.headers,
            };

            if (tokens?.accessToken) {
                headers.Authorization = `Bearer ${tokens.accessToken}`;
            }

            const response = await fetch(url, {
                ...options,
                headers,
            });

            const data = await response.json();

            if (!response.ok) {
                // Handle token expiration
                if (response.status === 401) {
                    await this.clearTokens();
                    // You might want to trigger a logout here
                }

                return {
                    success: false,
                    error: {
                        code: data.code || 'UNKNOWN_ERROR',
                        message: data.message || 'An error occurred',
                        details: data.details,
                    },
                };
            }

            return {
                success: true,
                data: data.data || data,
                message: data.message,
            };
        } catch (error) {
            console.error('API request failed:', error);
            return {
                success: false,
                error: {
                    code: 'NETWORK_ERROR',
                    message: 'Network request failed',
                    details: { error: error instanceof Error ? error.message : 'Unknown error' },
                },
            };
        }
    }

    // Authentication endpoints (Phase 1B: Anonymous-first)
    async createAnonymousAccount(form: CreateAccountForm): Promise<ApiResponse<{
        userId: string;
        username: string;
        token: string;
        refreshToken: string;
        recoveryPhrase: string;
        accountTier: string;
    }>> {
        const response = await this.request('/auth/create-anonymous', {
            method: 'POST',
            body: JSON.stringify(form),
        });

        if (response.success && response.data) {
            const tokens: AuthTokens = {
                accessToken: response.data.token,
                refreshToken: response.data.refreshToken,
                expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
            };
            await this.setTokens(tokens);
        }

        return response;
    }

    async recoverAccount(form: RecoverAccountForm): Promise<ApiResponse<{
        userId: string;
        username: string;
        token: string;
        refreshToken: string;
    }>> {
        const response = await this.request('/auth/recover', {
            method: 'POST',
            body: JSON.stringify(form),
        });

        if (response.success && response.data) {
            const tokens: AuthTokens = {
                accessToken: response.data.token,
                refreshToken: response.data.refreshToken,
                expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
            };
            await this.setTokens(tokens);
        }

        return response;
    }

    async refreshToken(refreshToken: string): Promise<ApiResponse<{ token: string }>> {
        return this.request('/auth/refresh', {
            method: 'POST',
            body: JSON.stringify({ refreshToken }),
        });
    }

    async logout(refreshToken: string): Promise<ApiResponse<{ message: string }>> {
        const response = await this.request('/auth/logout', {
            method: 'POST',
            body: JSON.stringify({ refreshToken }),
        });

        await this.clearTokens();
        return response;
    }

    async upgradeToEmail(email: string): Promise<ApiResponse<{ verificationRequired: boolean }>> {
        return this.request('/auth/upgrade/email', {
            method: 'POST',
            body: JSON.stringify({ email }),
        });
    }

    async upgradeToSocial(provider: 'google' | 'apple', credential: string): Promise<ApiResponse<{ message: string }>> {
        return this.request('/auth/upgrade/social', {
            method: 'POST',
            body: JSON.stringify({ provider, credential }),
        });
    }

    async checkRateLimit(): Promise<ApiResponse<{ allowed: boolean; remaining: number; accountTier: string }>> {
        return this.request('/auth/rate-limit');
    }

    async getCurrentUser(): Promise<ApiResponse<{ user: User }>> {
        return this.request('/auth/me');
    }

    // Wanna endpoints
    async createWanna(wannaData: CreateWannaForm): Promise<ApiResponse<Wanna>> {
        return this.request('/wannas', {
            method: 'POST',
            body: JSON.stringify(wannaData),
        });
    }

    async getActiveWannas(): Promise<ApiResponse<Wanna[]>> {
        return this.request('/wannas/active');
    }

    async cancelWanna(wannaId: string): Promise<ApiResponse<{ message: string }>> {
        return this.request(`/wannas/${wannaId}`, {
            method: 'DELETE',
        });
    }

    // Pod endpoints
    async getActivePods(): Promise<ApiResponse<Pod[]>> {
        return this.request('/pods/active');
    }

    async getPod(podId: string): Promise<ApiResponse<Pod>> {
        return this.request(`/pods/${podId}`);
    }

    async leavePod(podId: string): Promise<ApiResponse<{ message: string }>> {
        return this.request(`/pods/${podId}/leave`, {
            method: 'POST',
        });
    }

    async completePod(podId: string): Promise<ApiResponse<{ message: string }>> {
        return this.request(`/pods/${podId}/complete`, {
            method: 'POST',
        });
    }

    // Chat endpoints
    async getChatMessages(podId: string): Promise<ApiResponse<ChatMessage[]>> {
        return this.request(`/pods/${podId}/messages`);
    }

    async sendMessage(podId: string, content: string): Promise<ApiResponse<ChatMessage>> {
        return this.request(`/pods/${podId}/messages`, {
            method: 'POST',
            body: JSON.stringify({ content }),
        });
    }

    // Vibe summary endpoints
    async getVibeSummaries(): Promise<ApiResponse<VibeSummary[]>> {
        return this.request('/summaries');
    }

    async getVibeSummary(summaryId: string): Promise<ApiResponse<VibeSummary>> {
        return this.request(`/summaries/${summaryId}`);
    }

    // Utility methods
    getWebSocketUrl(): string {
        return this.wsUrl;
    }

    async isAuthenticated(): Promise<boolean> {
        const tokens = await this.getTokens();
        return tokens !== null;
    }

    // Wanna methods (Phase 1C: Wanna Creation & AI Intent Parsing)
    async createWanna(input: CreateWannaInput): Promise<ApiResponse<{
        wanna: {
            id: string;
            intent: any;
            locationName: string;
            expiresAt: string;
            remaining: number;
        };
    }>> {
        return this.request('/wannas', {
            method: 'POST',
            body: JSON.stringify(input),
        });
    }

    async getActiveWannas(): Promise<ApiResponse<{ wannas: Wanna[] }>> {
        return this.request('/wannas/active');
    }

    async cancelWanna(wannaId: string): Promise<ApiResponse<{ message: string }>> {
        return this.request(`/wannas/${wannaId}`, {
            method: 'DELETE',
        });
    }

    async getWannaSuggestions(query: string): Promise<ApiResponse<{ suggestions: string[] }>> {
        return this.request(`/wannas/suggestions?query=${encodeURIComponent(query)}`);
    }
}

// Create singleton instance
export const apiService = new ApiService();

// Export types for use in other files
export type { ApiResponse };
