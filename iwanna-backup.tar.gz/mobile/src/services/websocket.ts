import { io, Socket } from 'socket.io-client';
import * as SecureStore from 'expo-secure-store';
import type {
    WebSocketEvent,
    WebSocketEventType,
    ChatMessage,
    Pod,
    Location,
} from '../types';

const TOKEN_KEY = 'iwanna_auth_tokens';

class WebSocketService {
    private socket: Socket | null = null;
    private wsUrl: string;
    private reconnectAttempts = 0;
    private maxReconnectAttempts = 5;
    private reconnectDelay = 1000; // Start with 1 second
    private eventListeners: Map<string, Set<Function>> = new Map();

    constructor(wsUrl: string) {
        this.wsUrl = wsUrl;
    }

    // Initialize WebSocket connection
    async connect(): Promise<void> {
        try {
            const tokens = await this.getTokens();
            if (!tokens?.accessToken) {
                throw new Error('No authentication token available');
            }

            this.socket = io(this.wsUrl, {
                auth: {
                    token: tokens.accessToken,
                },
                transports: ['websocket'],
                timeout: 20000,
            });

            this.setupEventListeners();
            this.setupConnectionHandlers();
        } catch (error) {
            console.error('WebSocket connection failed:', error);
            throw error;
        }
    }

    // Disconnect WebSocket
    disconnect(): void {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
        }
        this.reconnectAttempts = 0;
    }

    // Join a pod room
    joinPod(podId: string): void {
        if (this.socket?.connected) {
            this.socket.emit('join_pod', { pod_id: podId });
        }
    }

    // Leave a pod room
    leavePod(podId: string): void {
        if (this.socket?.connected) {
            this.socket.emit('leave_pod', { pod_id: podId });
        }
    }

    // Send a chat message
    sendMessage(podId: string, content: string): void {
        if (this.socket?.connected) {
            this.socket.emit('send_message', {
                pod_id: podId,
                content,
            });
        }
    }

    // Send typing indicator
    sendTyping(podId: string, isTyping: boolean): void {
        if (this.socket?.connected) {
            this.socket.emit('typing', {
                pod_id: podId,
                is_typing: isTyping,
            });
        }
    }

    // Send location update
    sendLocationUpdate(location: Location): void {
        if (this.socket?.connected) {
            this.socket.emit('location_update', {
                location,
            });
        }
    }

    // Event listener management
    on(eventType: WebSocketEventType, callback: Function): void {
        if (!this.eventListeners.has(eventType)) {
            this.eventListeners.set(eventType, new Set());
        }
        this.eventListeners.get(eventType)!.add(callback);
    }

    off(eventType: WebSocketEventType, callback: Function): void {
        const listeners = this.eventListeners.get(eventType);
        if (listeners) {
            listeners.delete(callback);
        }
    }

    // Emit event to all listeners
    private emitEvent(eventType: WebSocketEventType, data: unknown): void {
        const listeners = this.eventListeners.get(eventType);
        if (listeners) {
            listeners.forEach((callback) => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in WebSocket event listener for ${eventType}:`, error);
                }
            });
        }
    }

    // Setup WebSocket event listeners
    private setupEventListeners(): void {
        if (!this.socket) return;

        // Pod events
        this.socket.on('pod_formed', (data: { pod: Pod }) => {
            this.emitEvent('pod_formed', data);
        });

        this.socket.on('match_found', (data: { pod_id: string; members: unknown[]; vibe_summary: string }) => {
            this.emitEvent('match_found', data);
        });

        this.socket.on('pod_expired', (data: { pod_id: string; summary: string }) => {
            this.emitEvent('pod_expired', data);
        });

        // Chat events
        this.socket.on('new_message', (data: { message: ChatMessage }) => {
            this.emitEvent('new_message', data);
        });

        this.socket.on('user_joined', (data: { user_id: string; pod_id: string }) => {
            this.emitEvent('user_joined', data);
        });

        this.socket.on('user_left', (data: { user_id: string; pod_id: string }) => {
            this.emitEvent('user_left', data);
        });

        this.socket.on('user_typing', (data: { user_id: string; pod_id: string; is_typing: boolean }) => {
            this.emitEvent('user_typing', data);
        });

        // AI assistant events
        this.socket.on('ai_action_response', (data: { action: string; data: unknown }) => {
            this.emitEvent('ai_action_response', data);
        });

        // Location events
        this.socket.on('location_update', (data: { user_id: string; location: Location }) => {
            this.emitEvent('location_update', data);
        });

        // Error handling
        this.socket.on('error', (error: { message: string; code: string }) => {
            console.error('WebSocket error:', error);
            this.emitEvent('error', error);
        });

        // Connection status
        this.socket.on('connect', () => {
            console.log('WebSocket connected');
            this.reconnectAttempts = 0;
            this.emitEvent('connected', {});
        });

        this.socket.on('disconnect', (reason: string) => {
            console.log('WebSocket disconnected:', reason);
            this.emitEvent('disconnected', { reason });
        });
    }

    // Setup connection handlers
    private setupConnectionHandlers(): void {
        if (!this.socket) return;

        this.socket.on('connect_error', (error: Error) => {
            console.error('WebSocket connection error:', error);
            this.handleReconnect();
        });

        this.socket.on('disconnect', (reason: string) => {
            if (reason === 'io server disconnect') {
                // Server disconnected, try to reconnect
                this.handleReconnect();
            }
        });
    }

    // Handle reconnection logic
    private handleReconnect(): void {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnection attempts reached');
            this.emitEvent('reconnect_failed', {});
            return;
        }

        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1); // Exponential backoff

        console.log(`Attempting to reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);

        setTimeout(() => {
            if (this.socket) {
                this.socket.connect();
            }
        }, delay);
    }

    // Get authentication tokens
    private async getTokens(): Promise<{ accessToken: string; refreshToken: string } | null> {
        try {
            const tokensJson = await SecureStore.getItemAsync(TOKEN_KEY);
            if (!tokensJson) return null;

            const tokens = JSON.parse(tokensJson);
            return tokens;
        } catch (error) {
            console.error('Error getting tokens for WebSocket:', error);
            return null;
        }
    }

    // Connection status
    isConnected(): boolean {
        return this.socket?.connected || false;
    }

    // Get connection state
    getConnectionState(): string {
        if (!this.socket) return 'disconnected';
        return this.socket.connected ? 'connected' : 'disconnected';
    }
}

// Create singleton instance
export const wsService = new WebSocketService(
    process.env.EXPO_PUBLIC_WS_URL || 'http://localhost:3001'
);

// Export types
export type { WebSocketEvent, WebSocketEventType };
