import { StyleSheet } from 'react-native';

// Iwanna's Living Interface Theme
// Everything must feel alive, warm, and organic

export const colors = {
    // Primary warm gradient colors
    primary: {
        50: '#FFF5F5', // Warm off-white
        100: '#FED7D7', // Soft coral
        200: '#FEB2B2', // Light coral
        300: '#FC8181', // Medium coral
        400: '#F56565', // Coral
        500: '#E53E3E', // Primary coral
        600: '#C53030', // Dark coral
        700: '#9B2C2C', // Deeper coral
        800: '#742A2A', // Darkest coral
        900: '#63171B', // Deepest coral
    },

    // Secondary warm tones
    secondary: {
        50: '#FFFAF0', // Cream
        100: '#FEEBC8', // Light peach
        200: '#FBD38D', // Peach
        300: '#F6AD55', // Orange
        400: '#ED8936', // Warm orange
        500: '#DD6B20', // Primary orange
        600: '#C05621', // Dark orange
        700: '#9C4221', // Deeper orange
        800: '#7B341E', // Darkest orange
        900: '#652B19', // Deepest orange
    },

    // Neutral warm grays (never pure black/white)
    neutral: {
        50: '#FEFCFB', // Warm off-white
        100: '#F7F5F3', // Light warm gray
        200: '#E7E3E0', // Light gray
        300: '#D1C7C0', // Medium light gray
        400: '#B8A99E', // Medium gray
        500: '#9B8B7F', // Base gray
        600: '#7A6B5F', // Dark gray
        700: '#5D4E42', // Darker gray
        800: '#3D3329', // Very dark gray
        900: '#2A2523', // Warm dark (never pure black)
    },

    // Status colors with warm undertones
    success: '#48BB78', // Warm green
    warning: '#ED8936', // Warm orange
    error: '#F56565', // Warm red
    info: '#4299E1', // Warm blue

    // Background colors
    background: {
        primary: '#FEFCFB', // Warm off-white
        secondary: '#F7F5F3', // Light warm gray
        tertiary: '#E7E3E0', // Medium warm gray
        dark: '#2A2523', // Warm dark
    },

    // Text colors
    text: {
        primary: '#2A2523', // Warm dark (never pure black)
        secondary: '#5D4E42', // Medium warm gray
        tertiary: '#9B8B7F', // Light warm gray
        inverse: '#FEFCFB', // Warm off-white
        accent: '#E53E3E', // Primary coral
    },

    // Interactive colors
    interactive: {
        hover: 'rgba(229, 62, 62, 0.1)', // Coral with 10% opacity
        pressed: 'rgba(229, 62, 62, 0.2)', // Coral with 20% opacity
        disabled: 'rgba(155, 139, 127, 0.3)', // Gray with 30% opacity
    },
};

export const typography = {
    // Font families
    fontFamily: {
        regular: 'System', // SF Pro on iOS, Roboto on Android
        medium: 'System',
        bold: 'System',
    },

    // Font sizes with generous spacing
    fontSize: {
        xs: 12,
        sm: 14,
        base: 16, // Base size
        lg: 18,
        xl: 20,
        '2xl': 24,
        '3xl': 30,
        '4xl': 36,
        '5xl': 48,
    },

    // Line heights for breathability
    lineHeight: {
        tight: 1.2,
        normal: 1.5, // Generous spacing
        relaxed: 1.75,
    },

    // Letter spacing
    letterSpacing: {
        tight: -0.5,
        normal: 0,
        wide: 0.5,
    },
};

export const spacing = {
    // 8px base unit system
    0: 0,
    1: 4,
    2: 8,
    3: 12,
    4: 16,
    5: 20,
    6: 24,
    8: 32,
    10: 40,
    12: 48,
    16: 64,
    20: 80,
    24: 96,
    32: 128,
};

export const borderRadius = {
    none: 0,
    sm: 4,
    base: 8,
    md: 12,
    lg: 16,
    xl: 24,
    full: 9999,
};

export const shadows = {
    // Soft, warm shadows
    sm: {
        shadowColor: colors.neutral[900],
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
    },
    base: {
        shadowColor: colors.neutral[900],
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15,
        shadowRadius: 4,
        elevation: 4,
    },
    lg: {
        shadowColor: colors.neutral[900],
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 8,
    },
};

// Animation presets for the living interface
export const animations = {
    // Spring physics for organic motion
    spring: {
        damping: 15,
        stiffness: 150,
        mass: 1,
    },

    // Breathing animation (subtle scale pulse)
    breathing: {
        scale: {
            from: 1,
            to: 1.02,
            duration: 3000, // 3 seconds
        },
    },

    // Gentle fade in with slight upward movement
    fadeInUp: {
        opacity: {
            from: 0,
            to: 1,
            duration: 300,
        },
        translateY: {
            from: 10,
            to: 0,
            duration: 300,
        },
    },

    // Gentle fade out with slight downward movement
    fadeOutDown: {
        opacity: {
            from: 1,
            to: 0,
            duration: 200,
        },
        translateY: {
            from: 0,
            to: 10,
            duration: 200,
        },
    },

    // Button press animation
    press: {
        scale: {
            from: 1,
            to: 0.97,
            duration: 100,
        },
    },

    // Glow pulse for accent elements
    glow: {
        opacity: {
            from: 0.6,
            to: 1,
            duration: 2000,
        },
    },
};

// Common styles for the living interface
export const commonStyles = StyleSheet.create({
    // Container styles
    container: {
        flex: 1,
        backgroundColor: colors.background.primary,
    },

    safeArea: {
        flex: 1,
        backgroundColor: colors.background.primary,
    },

    // Text styles with warm, human feel
    heading1: {
        fontSize: typography.fontSize['4xl'],
        fontWeight: 'bold',
        color: colors.text.primary,
        lineHeight: typography.fontSize['4xl'] * typography.lineHeight.normal,
        letterSpacing: typography.letterSpacing.tight,
    },

    heading2: {
        fontSize: typography.fontSize['3xl'],
        fontWeight: 'bold',
        color: colors.text.primary,
        lineHeight: typography.fontSize['3xl'] * typography.lineHeight.normal,
        letterSpacing: typography.letterSpacing.tight,
    },

    heading3: {
        fontSize: typography.fontSize['2xl'],
        fontWeight: '600',
        color: colors.text.primary,
        lineHeight: typography.fontSize['2xl'] * typography.lineHeight.normal,
    },

    body: {
        fontSize: typography.fontSize.base,
        color: colors.text.primary,
        lineHeight: typography.fontSize.base * typography.lineHeight.normal,
    },

    bodySecondary: {
        fontSize: typography.fontSize.base,
        color: colors.text.secondary,
        lineHeight: typography.fontSize.base * typography.lineHeight.normal,
    },

    caption: {
        fontSize: typography.fontSize.sm,
        color: colors.text.tertiary,
        lineHeight: typography.fontSize.sm * typography.lineHeight.normal,
    },

    // Button styles with organic feel
    button: {
        paddingHorizontal: spacing[6],
        paddingVertical: spacing[4],
        borderRadius: borderRadius.lg,
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: 48, // Minimum touch target
    },

    buttonPrimary: {
        backgroundColor: colors.primary[500],
        ...shadows.sm,
    },

    buttonSecondary: {
        backgroundColor: colors.background.secondary,
        borderWidth: 1,
        borderColor: colors.neutral[300],
    },

    // Card styles with gentle shadows
    card: {
        backgroundColor: colors.background.primary,
        borderRadius: borderRadius.lg,
        padding: spacing[6],
        ...shadows.base,
    },

    // Input styles
    input: {
        borderWidth: 1,
        borderColor: colors.neutral[300],
        borderRadius: borderRadius.md,
        paddingHorizontal: spacing[4],
        paddingVertical: spacing[3],
        fontSize: typography.fontSize.base,
        color: colors.text.primary,
        backgroundColor: colors.background.primary,
    },

    inputFocused: {
        borderColor: colors.primary[500],
        ...shadows.sm,
    },
});

// Gradient definitions for warm, living feel
export const gradients = {
    primary: ['#FF6B6B', '#FF8E53', '#FF6B9D'], // Coral to peach to pink
    secondary: ['#FFEAA7', '#FDCB6E', '#E17055'], // Cream to orange
    background: ['#FEFCFB', '#F7F5F3'], // Warm off-white gradient
    accent: ['#FF6B6B', '#4ECDC4'], // Coral to teal
};

export default {
    colors,
    typography,
    spacing,
    borderRadius,
    shadows,
    animations,
    commonStyles,
    gradients,
};
