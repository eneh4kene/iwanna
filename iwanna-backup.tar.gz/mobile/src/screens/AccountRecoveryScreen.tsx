import React, { useState } from 'react';
import { 
    View, 
    Text, 
    TextInput, 
    StyleSheet, 
    Pressable,
    KeyboardAvoidingView,
    Platform 
} from 'react-native';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withSequence,
    withTiming,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { useAuthStore } from '../store';
import { colors, typography } from '../constants/theme';

interface AccountRecoveryScreenProps {
    navigation: any;
}

export const AccountRecoveryScreen: React.FC<AccountRecoveryScreenProps> = ({ navigation }) => {
    const [phrase, setPhrase] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    
    const recoverAccount = useAuthStore((state) => state.recoverAccount);
    const translateX = useSharedValue(0);

    const shakeAnimation = () => {
        translateX.value = withSequence(
            withTiming(-10, { duration: 50 }),
            withTiming(10, { duration: 50 }),
            withTiming(-10, { duration: 50 }),
            withTiming(0, { duration: 50 })
        );
    };

    const animatedStyle = useAnimatedStyle(() => ({
        transform: [{ translateX: translateX.value }],
    }));

    const handleRecover = async () => {
        if (!phrase.trim()) {
            setError('Please enter your recovery phrase');
            shakeAnimation();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
            return;
        }

        setIsLoading(true);
        setError('');

        try {
            const deviceInfo = {
                platform: Platform.OS as 'ios' | 'android' | 'web',
                osVersion: Platform.Version.toString(),
                appVersion: Constants.expoConfig?.version || '1.0.0',
                deviceModel: Device.modelName || 'Unknown',
            };

            await recoverAccount({ 
                recoveryPhrase: phrase.trim(), 
                deviceInfo 
            });
            
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            navigation.navigate('Main');
        } catch (err: any) {
            setError(err.response?.data?.message || 'Recovery failed. Check your phrase and try again.');
            shakeAnimation();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView 
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <View style={styles.content}>
                <Text style={styles.title}>Recover your account</Text>
                <Text style={styles.subtitle}>
                    Enter the 12-word recovery phrase you saved when creating your account
                </Text>

                <Animated.View style={[styles.inputContainer, animatedStyle]}>
                    <TextInput
                        style={styles.input}
                        placeholder="word1 word2 word3 word4..."
                        placeholderTextColor={colors.text.secondary}
                        value={phrase}
                        onChangeText={setPhrase}
                        multiline
                        numberOfLines={3}
                        autoCapitalize="none"
                        autoCorrect={false}
                        autoFocus
                    />
                </Animated.View>

                {error ? (
                    <Text style={styles.error}>{error}</Text>
                ) : null}

                <Pressable
                    style={[styles.button, isLoading && styles.buttonLoading]}
                    onPress={handleRecover}
                    disabled={isLoading}
                >
                    <Text style={styles.buttonText}>
                        {isLoading ? 'Recovering...' : 'Recover account'}
                    </Text>
                </Pressable>

                <Pressable 
                    style={styles.backButton}
                    onPress={() => navigation.goBack()}
                >
                    <Text style={styles.backButtonText}>Back</Text>
                </Pressable>
            </View>
        </KeyboardAvoidingView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.background.primary,
    },
    content: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 60,
    },
    title: {
        fontSize: typography.fontSize['3xl'],
        fontWeight: 'bold',
        color: colors.text.primary,
        marginBottom: 12,
    },
    subtitle: {
        fontSize: typography.fontSize.base,
        color: colors.text.secondary,
        marginBottom: 32,
        lineHeight: typography.lineHeight.normal * typography.fontSize.base,
    },
    inputContainer: {
        marginBottom: 16,
    },
    input: {
        backgroundColor: colors.background.secondary,
        padding: 16,
        borderRadius: 12,
        fontSize: typography.fontSize.sm,
        color: colors.text.primary,
        minHeight: 100,
        fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
        textAlignVertical: 'top',
    },
    error: {
        color: colors.error,
        fontSize: typography.fontSize.sm,
        marginBottom: 16,
    },
    button: {
        backgroundColor: colors.primary,
        paddingVertical: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 16,
    },
    buttonLoading: {
        opacity: 0.7,
    },
    buttonText: {
        color: colors.text.primary,
        fontSize: typography.fontSize.lg,
        fontWeight: '600',
    },
    backButton: {
        paddingVertical: 12,
        alignItems: 'center',
    },
    backButtonText: {
        color: colors.text.secondary,
        fontSize: typography.fontSize.base,
    },
});
