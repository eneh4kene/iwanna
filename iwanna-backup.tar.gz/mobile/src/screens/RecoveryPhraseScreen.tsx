import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Alert, Platform } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { useAuthStore } from '../store';
import { colors, typography } from '../constants/theme';

interface RecoveryPhraseScreenProps {
    navigation: any;
}

export const RecoveryPhraseScreen: React.FC<RecoveryPhraseScreenProps> = ({ navigation }) => {
    const recoveryPhrase = useAuthStore((state) => state.recoveryPhrase);
    const clearRecoveryPhrase = useAuthStore((state) => state.clearRecoveryPhrase);
    const [saved, setSaved] = useState(false);

    const handleCopy = async () => {
        if (recoveryPhrase) {
            await Clipboard.setStringAsync(recoveryPhrase);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            Alert.alert('Copied!', 'Recovery phrase copied to clipboard');
        }
    };

    const handleContinue = () => {
        if (!saved) {
            Alert.alert(
                'Are you sure?',
                "You won't be able to recover your account without this phrase",
                [
                    { text: 'Go back', style: 'cancel' },
                    { 
                        text: 'I understand', 
                        onPress: () => {
                            clearRecoveryPhrase();
                            navigation.navigate('Main');
                        }
                    }
                ]
            );
        } else {
            clearRecoveryPhrase();
            navigation.navigate('Main');
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.content}>
                <Text style={styles.title}>Save your recovery phrase</Text>
                
                <Text style={styles.warning}>
                    ⚠️ This is the ONLY way to recover your account on a new device.
                    We can't help if you lose it.
                </Text>

                <View style={styles.phraseContainer}>
                    <Text style={styles.phrase} selectable>
                        {recoveryPhrase}
                    </Text>
                </View>

                <Pressable style={styles.copyButton} onPress={handleCopy}>
                    <Text style={styles.copyButtonText}>Copy to clipboard</Text>
                </Pressable>

                <View style={styles.checkboxContainer}>
                    <Pressable
                        style={[styles.checkbox, saved && styles.checkboxChecked]}
                        onPress={() => setSaved(!saved)}
                    >
                        {saved && <Text style={styles.checkmark}>✓</Text>}
                    </Pressable>
                    <Text style={styles.checkboxLabel}>
                        I've saved my recovery phrase safely
                    </Text>
                </View>

                <Pressable
                    style={[styles.continueButton, !saved && styles.continueButtonDisabled]}
                    onPress={handleContinue}
                >
                    <Text style={styles.continueButtonText}>Continue</Text>
                </Pressable>

                <Text style={styles.tip}>
                    💡 Tip: Write it down on paper or save in a password manager
                </Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.background.primary,
    },
    content: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: 60,
    },
    title: {
        fontSize: typography.fontSize['3xl'],
        fontWeight: 'bold',
        color: colors.text.primary,
        marginBottom: 16,
    },
    warning: {
        fontSize: typography.fontSize.base,
        color: colors.error,
        marginBottom: 24,
        lineHeight: typography.lineHeight.normal * typography.fontSize.base,
    },
    phraseContainer: {
        backgroundColor: colors.background.secondary,
        padding: 20,
        borderRadius: 16,
        marginBottom: 16,
    },
    phrase: {
        fontSize: typography.fontSize.base,
        color: colors.text.primary,
        lineHeight: typography.lineHeight.normal * typography.fontSize.base,
        fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    },
    copyButton: {
        backgroundColor: colors.primary,
        paddingVertical: 14,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 32,
    },
    copyButtonText: {
        color: colors.text.primary,
        fontSize: typography.fontSize.base,
        fontWeight: '600',
    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 24,
    },
    checkbox: {
        width: 28,
        height: 28,
        borderRadius: 6,
        borderWidth: 2,
        borderColor: colors.text.secondary,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    checkboxChecked: {
        backgroundColor: colors.success,
        borderColor: colors.success,
    },
    checkmark: {
        color: colors.text.primary,
        fontSize: 18,
        fontWeight: 'bold',
    },
    checkboxLabel: {
        fontSize: typography.fontSize.sm,
        color: colors.text.primary,
        flex: 1,
    },
    continueButton: {
        backgroundColor: colors.primary,
        paddingVertical: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 16,
    },
    continueButtonDisabled: {
        opacity: 0.4,
    },
    continueButtonText: {
        color: colors.text.primary,
        fontSize: typography.fontSize.lg,
        fontWeight: '600',
    },
    tip: {
        fontSize: typography.fontSize.sm,
        color: colors.text.secondary,
        textAlign: 'center',
        fontStyle: 'italic',
    },
});
