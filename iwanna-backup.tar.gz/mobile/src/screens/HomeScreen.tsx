// Home Screen - Wanna Creation Interface
// Phase 1C: Wanna Creation & AI Intent Parsing

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import * as Location from 'expo-location';
import * as Haptics from 'expo-haptics';
import { useWannaStore } from '../store/wannaStore';
import { useAuthStore } from '../store';
import { colors } from '../constants/theme';

const MOOD_EMOJIS = ['😎', '🤩', '🧠', '💬', '🎨', '🔥', '🌟', '✨'];

export const HomeScreen = ({ navigation }) => {
  const [text, setText] = useState('');
  const [selectedMood, setSelectedMood] = useState<string | undefined>();
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  
  const createWanna = useWannaStore(state => state.createWanna);
  const isCreating = useWannaStore(state => state.isCreating);
  const user = useAuthStore(state => state.user);
  
  const inputRef = useRef<TextInput>(null);

  // Breathing animation for button
  const scale = useSharedValue(1);

  useEffect(() => {
    if (text.length >= 3 && !isCreating) {
      scale.value = withRepeat(
        withSequence(
          withTiming(1.02, { duration: 1500 }),
          withTiming(1.0, { duration: 1500 })
        ),
        -1,
        false
      );
    } else {
      scale.value = withTiming(1);
    }
  }, [text, isCreating]);

  const animatedButtonStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handleSubmit = async () => {
    if (text.length < 3) {
      Alert.alert('Tell us more', 'What do you wanna do? Be specific! 🌟');
      return;
    }

    // Request location permission
    const { status } = await Location.requestForegroundPermissionsAsync();
    
    if (status !== 'granted') {
      Alert.alert(
        'Location needed',
        'We need your location to find people nearby. Want to enable it?',
        [
          { text: 'Not now', style: 'cancel' },
          { 
            text: 'Enable', 
            onPress: () => Location.requestForegroundPermissionsAsync() 
          },
        ]
      );
      return;
    }

    setIsGettingLocation(true);

    try {
      // Get current location
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      // Create wanna
      await createWanna({
        text,
        moodEmoji: selectedMood,
        location: {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
          accuracy: location.coords.accuracy || 100,
        },
      });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      // Clear input
      setText('');
      setSelectedMood(undefined);

      // Navigate to matching screen (Phase 1D will implement this)
      navigation.navigate('Matching');
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      
      Alert.alert(
        'Oops!',
        error.message || 'Something went wrong. Mind trying again?'
      );
    } finally {
      setIsGettingLocation(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Ambient gradient background */}
      <View style={styles.gradientBackground} />

      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.greeting}>
            Hey {user?.username.split('_')[0]} 👋
          </Text>
          <Text style={styles.title}>What do you wanna do?</Text>
        </View>

        {/* Input Section */}
        <View style={styles.inputSection}>
          <TextInput
            ref={inputRef}
            style={styles.input}
            placeholder="I wanna..."
            placeholderTextColor={colors.text.secondary}
            value={text}
            onChangeText={setText}
            multiline
            numberOfLines={3}
            maxLength={200}
            autoFocus
            editable={!isCreating}
          />
          
          <Text style={styles.charCount}>
            {text.length}/200
          </Text>
        </View>

        {/* Mood Selector */}
        <View style={styles.moodSection}>
          <Text style={styles.moodLabel}>How are you feeling?</Text>
          <View style={styles.moodGrid}>
            {MOOD_EMOJIS.map(emoji => (
              <Pressable
                key={emoji}
                style={[
                  styles.moodButton,
                  selectedMood === emoji && styles.moodButtonSelected,
                ]}
                onPress={() => {
                  setSelectedMood(selectedMood === emoji ? undefined : emoji);
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
              >
                <Text style={styles.moodEmoji}>{emoji}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Submit Button */}
        <Animated.View style={[styles.buttonWrapper, animatedButtonStyle]}>
          <Pressable
            style={[
              styles.button,
              (text.length < 3 || isCreating || isGettingLocation) && styles.buttonDisabled,
            ]}
            onPress={handleSubmit}
            disabled={text.length < 3 || isCreating || isGettingLocation}
          >
            <Text style={styles.buttonText}>
              {isGettingLocation
                ? 'Getting location...'
                : isCreating
                ? 'Finding your vibe...'
                : 'Find your vibe'}
            </Text>
          </Pressable>
        </Animated.View>

        {/* Info */}
        <Text style={styles.info}>
          We'll match you with 2-4 people nearby who feel the same way ✨
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  gradientBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.2,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
  },
  header: {
    marginBottom: 32,
  },
  greeting: {
    fontSize: 16,
    color: colors.text.secondary,
    marginBottom: 8,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: colors.text.primary,
  },
  inputSection: {
    marginBottom: 24,
  },
  input: {
    backgroundColor: colors.background.secondary,
    padding: 20,
    borderRadius: 16,
    fontSize: 18,
    color: colors.text.primary,
    minHeight: 120,
    textAlignVertical: 'top',
  },
  charCount: {
    textAlign: 'right',
    marginTop: 8,
    fontSize: 12,
    color: colors.text.secondary,
  },
  moodSection: {
    marginBottom: 32,
  },
  moodLabel: {
    fontSize: 16,
    color: colors.text.secondary,
    marginBottom: 12,
  },
  moodGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  moodButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.background.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  moodButtonSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primary + '20',
  },
  moodEmoji: {
    fontSize: 28,
  },
  buttonWrapper: {
    marginBottom: 16,
  },
  button: {
    backgroundColor: colors.primary,
    paddingVertical: 18,
    borderRadius: 16,
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.4,
  },
  buttonText: {
    color: colors.text.inverse,
    fontSize: 18,
    fontWeight: '600',
  },
  info: {
    fontSize: 14,
    color: colors.text.secondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});
