import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Platform } from 'react-native';
import Animated, { 
    useSharedValue, 
    useAnimatedStyle, 
    withRepeat, 
    withSequence,
    withTiming 
} from 'react-native-reanimated';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { useAuthStore } from '../store';
import { colors, typography } from '../constants/theme';

interface AgeGateScreenProps {
    navigation: any;
}

export const AgeGateScreen: React.FC<AgeGateScreenProps> = ({ navigation }) => {
    const [isOver18, setIsOver18] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    
    const createAccount = useAuthStore((state) => state.createAccount);

    // Breathing animation for button
    const scale = useSharedValue(1);

    React.useEffect(() => {
        if (isOver18) {
            scale.value = withRepeat(
                withSequence(
                    withTiming(1.02, { duration: 1500 }),
                    withTiming(1.0, { duration: 1500 })
                ),
                -1,
                false
            );
        } else {
            scale.value = withTiming(1);
        }
    }, [isOver18]);

    const animatedButtonStyle = useAnimatedStyle(() => ({
        transform: [{ scale: scale.value }],
    }));

    const handleContinue = async () => {
        if (!isOver18) {
            setError('You must be 18 or older to use Iwanna');
            return;
        }

        setIsLoading(true);
        setError('');

        try {
            // Gather device info
            const deviceInfo = {
                platform: Platform.OS as 'ios' | 'android' | 'web',
                osVersion: Platform.Version.toString(),
                appVersion: Constants.expoConfig?.version || '1.0.0',
                deviceModel: Device.modelName || 'Unknown',
            };

            await createAccount({ isOver18: true, deviceInfo });
            
            // Navigate to recovery phrase screen
            navigation.navigate('RecoveryPhrase');
        } catch (err: any) {
            setError(err.response?.data?.message || 'Something went wrong. Try again?');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <View style={styles.container}>
            {/* Ambient gradient background */}
            <View style={styles.gradientBackground} />

            <View style={styles.content}>
                <Text style={styles.title}>Welcome to Iwanna</Text>
                <Text style={styles.subtitle}>
                    Where spontaneous connections happen ✨
                </Text>

                <View style={styles.ageCheckContainer}>
                    <Pressable
                        style={[
                            styles.checkbox,
                            isOver18 && styles.checkboxChecked
                        ]}
                        onPress={() => setIsOver18(!isOver18)}
                    >
                        {isOver18 && <Text style={styles.checkmark}>✓</Text>}
                    </Pressable>
                    
                    <Text style={styles.checkboxLabel}>
                        I'm 18 years or older
                    </Text>
                </View>

                {error ? (
                    <Text style={styles.error}>{error}</Text>
                ) : null}

                <Animated.View style={[styles.buttonWrapper, animatedButtonStyle]}>
                    <Pressable
                        style={[
                            styles.button,
                            !isOver18 && styles.buttonDisabled,
                            isLoading && styles.buttonLoading
                        ]}
                        onPress={handleContinue}
                        disabled={!isOver18 || isLoading}
                    >
                        <Text style={styles.buttonText}>
                            {isLoading ? 'Creating your vibe...' : "Let's go"}
                        </Text>
                    </Pressable>
                </Animated.View>

                <Text style={styles.disclaimer}>
                    By continuing, you agree to our Terms of Service and Privacy Policy
                </Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.background.primary,
    },
    gradientBackground: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        opacity: 0.3,
        // Add gradient here with expo-linear-gradient
    },
    content: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 32,
    },
    title: {
        fontSize: typography.fontSize['4xl'],
        fontWeight: 'bold',
        color: colors.text.primary,
        marginBottom: 12,
        textAlign: 'center',
    },
    subtitle: {
        fontSize: typography.fontSize.lg,
        color: colors.text.secondary,
        marginBottom: 48,
        textAlign: 'center',
    },
    ageCheckContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 32,
    },
    checkbox: {
        width: 32,
        height: 32,
        borderRadius: 8,
        borderWidth: 2,
        borderColor: colors.text.secondary,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    checkboxChecked: {
        backgroundColor: colors.primary,
        borderColor: colors.primary,
    },
    checkmark: {
        color: colors.text.primary,
        fontSize: 20,
        fontWeight: 'bold',
    },
    checkboxLabel: {
        fontSize: typography.fontSize.base,
        color: colors.text.primary,
    },
    error: {
        color: colors.error,
        fontSize: typography.fontSize.sm,
        marginBottom: 16,
        textAlign: 'center',
    },
    buttonWrapper: {
        width: '100%',
    },
    button: {
        backgroundColor: colors.primary,
        paddingVertical: 18,
        paddingHorizontal: 48,
        borderRadius: 16,
        alignItems: 'center',
    },
    buttonDisabled: {
        opacity: 0.4,
    },
    buttonLoading: {
        opacity: 0.7,
    },
    buttonText: {
        color: colors.text.primary,
        fontSize: typography.fontSize.lg,
        fontWeight: '600',
    },
    disclaimer: {
        marginTop: 24,
        fontSize: typography.fontSize.xs,
        color: colors.text.secondary,
        textAlign: 'center',
        paddingHorizontal: 16,
    },
});
