// Core Iwanna Types
// All types must be strict and explicit - no 'any' types allowed

// User types (Phase 1B: Anonymous-first authentication)
export interface User {
    id: string;
    username: string;
    accountTier: AccountTier;
    createdAt: Date;
    lastActive: Date;
    trustScore: number;
    wannasCreated: number;
    podsJoined: number;
    connectionsMade: number;
}

export type AccountTier = 'anonymous' | 'email' | 'authenticated';

export type EnergyLevel = 'low' | 'medium' | 'high';

// Wanna types (Phase 1C: Wanna Creation & AI Intent Parsing)
export interface Wanna {
    id: string;
    text: string;
    moodEmoji?: string;
    intent: {
        activity: string;
        category: string;
        energy_level: 'low' | 'medium' | 'high';
        keywords: string[];
        emotional_tone: string;
    };
    locationName: string;
    status: 'active' | 'matching' | 'matched' | 'expired' | 'cancelled';
    createdAt: string;
    expiresAt: string;
}

export interface CreateWannaInput {
    text: string;
    moodEmoji?: string;
    location: {
        latitude: number;
        longitude: number;
        accuracy: number;
    };
}

// Pod types
export interface Pod {
    id: string;
    status: PodStatus;
    vibeSummary: string;
    collectiveIntent: CollectiveIntent;
    centroidLocation: Location;
    suggestedVenues: Venue[];
    createdAt: Date;
    expiresAt: Date;
    completedAt?: Date;
}

export interface CollectiveIntent {
    primaryActivity: string;
    energyLevel: EnergyLevel;
    vibeKeywords: string[];
    groupSize: number;
    estimatedDuration: number; // in minutes
}

export type PodStatus = 'forming' | 'active' | 'completed' | 'expired';

// Pod member types
export interface PodMember {
    id: string;
    podId: string;
    userId: string;
    wannaId: string;
    joinedAt: Date;
    status: PodMemberStatus;
    markedComplete: boolean;
}

export type PodMemberStatus = 'active' | 'left' | 'removed';

// Chat types
export interface ChatMessage {
    id: string;
    podId: string;
    userId: string;
    content: string;
    messageType: MessageType;
    metadata?: MessageMetadata;
    createdAt: Date;
}

export type MessageType = 'user' | 'system' | 'ai';

export interface MessageMetadata {
    actions?: ChatAction[];
    locationData?: Location;
    aiContext?: string;
}

export interface ChatAction {
    type: 'suggest_venue' | 'icebreaker' | 'location_share' | 'pod_complete';
    data: Record<string, unknown>;
}

// Vibe summary types
export interface VibeSummary {
    id: string;
    userId: string;
    podId: string;
    summaryText: string;
    connectionsMade: number;
    generatedAt: Date;
}

// Location types
export interface Location {
    latitude: number;
    longitude: number;
    address?: string;
    city?: string;
    state?: string;
    country?: string;
}

// Venue types
export interface Venue {
    id: string;
    name: string;
    location: Location;
    category: string;
    rating?: number;
    priceLevel?: number;
    distance?: number; // in miles
    description?: string;
}

// API Response types
export interface ApiResponse<T = unknown> {
    success: boolean;
    data?: T;
    error?: ApiError;
    message?: string;
}

export interface ApiError {
    code: string;
    message: string;
    details?: Record<string, unknown>;
}

// Authentication types (Phase 1B: Anonymous-first)
export interface AuthTokens {
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
}

export interface AuthState {
    isAuthenticated: boolean;
    user?: User;
    tokens?: AuthTokens;
    isLoading: boolean;
    error?: string;
    recoveryPhrase?: string; // Only during signup flow
}

export interface DeviceInfo {
    platform: 'ios' | 'android' | 'web';
    osVersion: string;
    appVersion: string;
    deviceModel?: string;
}

// WebSocket event types
export interface WebSocketEvent {
    type: WebSocketEventType;
    data: unknown;
    timestamp: Date;
}

export type WebSocketEventType =
    | 'pod_formed'
    | 'match_found'
    | 'new_message'
    | 'user_joined'
    | 'user_left'
    | 'user_typing'
    | 'pod_expired'
    | 'ai_action_response'
    | 'location_update';

// Navigation types
export type RootStackParamList = {
    Auth: undefined;
    Main: undefined;
    WannaCreate: undefined;
    PodChat: { podId: string };
    VibeSummary: { summaryId: string };
    Settings: undefined;
};

export type MainTabParamList = {
    Home: undefined;
    Pods: undefined;
    Profile: undefined;
};

// State management types
export interface AppState {
    auth: AuthState;
    wannas: WannaState;
    pods: PodState;
    chat: ChatState;
    location: LocationState;
}

export interface WannaState {
    activeWannas: Wanna[];
    isCreating: boolean;
    error: string | null;
}

export interface PodState {
    activePods: Pod[];
    isLoading: boolean;
    error?: string;
}

export interface ChatState {
    messages: Record<string, ChatMessage[]>; // podId -> messages
    typingUsers: Record<string, string[]>; // podId -> userIds
    isLoading: boolean;
    error?: string;
}

export interface LocationState {
    currentLocation?: Location;
    isTracking: boolean;
    permissionStatus: 'granted' | 'denied' | 'undetermined';
    error?: string;
}

// Form types (Phase 1B: Anonymous-first)
export interface CreateWannaForm {
    text: string;
    mood?: string;
    location: Location;
}

export interface CreateAccountForm {
    isOver18: boolean;
    deviceInfo: DeviceInfo;
}

export interface RecoverAccountForm {
    recoveryPhrase: string;
    deviceInfo?: DeviceInfo;
}

// Utility types
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

// Animation types
export interface AnimationConfig {
    duration: number;
    easing?: 'ease' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'linear';
    delay?: number;
    iterations?: number | 'infinite';
}

// Environment types
export interface EnvironmentConfig {
    apiUrl: string;
    wsUrl: string;
    env: 'development' | 'staging' | 'production';
    enableAnalytics: boolean;
    enableCrashReporting: boolean;
}

// Error types
export class IwannaError extends Error {
    constructor(
        message: string,
        public code: string,
        public details?: Record<string, unknown>
    ) {
        super(message);
        this.name = 'IwannaError';
    }
}

export class ValidationError extends IwannaError {
    constructor(message: string, details?: Record<string, unknown>) {
        super(message, 'VALIDATION_ERROR', details);
        this.name = 'ValidationError';
    }
}

export class NetworkError extends IwannaError {
    constructor(message: string, details?: Record<string, unknown>) {
        super(message, 'NETWORK_ERROR', details);
        this.name = 'NetworkError';
    }
}

export class AuthError extends IwannaError {
    constructor(message: string, details?: Record<string, unknown>) {
        super(message, 'AUTH_ERROR', details);
        this.name = 'AuthError';
    }
}
