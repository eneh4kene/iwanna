// Wanna Store for Managing Wanna Creation and State
// Phase 1C: Wanna Creation & AI Intent Parsing

import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import { Wanna, CreateWannaInput } from '../types';

interface WannaStore extends WannaState {
    // Actions
    createWanna: (input: CreateWannaInput) => Promise<void>;
    getActiveWannas: () => Promise<void>;
    cancelWanna: (wannaId: string) => Promise<void>;
    clearError: () => void;
}

interface WannaState {
    activeWannas: Wanna[];
    isCreating: boolean;
    error: string | null;
}

export const useWannaStore = create<WannaStore>()(
    devtools(
        persist(
            immer((set, get) => ({
                activeWannas: [],
                isCreating: false,
                error: null,

                createWanna: async (input: CreateWannaInput) => {
                    set((state) => {
                        state.isCreating = true;
                        state.error = null;
                    });

                    try {
                        // Import API service dynamically to avoid circular imports
                        const { apiService } = await import('../services/api');

                        const response = await apiService.createWanna(input);

                        if (response.success && response.data) {
                            // Refresh active wannas
                            await get().getActiveWannas();
                        } else {
                            throw new Error(response.error?.message || 'Failed to create wanna');
                        }
                    } catch (error: any) {
                        const message = error.response?.data?.message || error.message || 'Failed to create wanna';
                        set((state) => {
                            state.error = message;
                        });
                        throw new Error(message);
                    } finally {
                        set((state) => {
                            state.isCreating = false;
                        });
                    }
                },

                getActiveWannas: async () => {
                    try {
                        const { apiService } = await import('../services/api');
                        const response = await apiService.getActiveWannas();

                        if (response.success && response.data) {
                            set((state) => {
                                state.activeWannas = response.data.wannas;
                            });
                        }
                    } catch (error) {
                        console.error('Failed to fetch wannas:', error);
                    }
                },

                cancelWanna: async (wannaId: string) => {
                    try {
                        const { apiService } = await import('../services/api');
                        await apiService.cancelWanna(wannaId);

                        // Remove from local state
                        set((state) => {
                            state.activeWannas = state.activeWannas.filter(w => w.id !== wannaId);
                        });
                    } catch (error: any) {
                        const message = error.response?.data?.message || error.message || 'Failed to cancel wanna';
                        set((state) => {
                            state.error = message;
                        });
                        throw new Error(message);
                    }
                },

                clearError: () => set((state) => {
                    state.error = null;
                }),
            })),
            {
                name: 'iwanna-wanna-store',
                partialize: (state) => ({
                    activeWannas: state.activeWannas,
                }),
            }
        ),
        { name: 'WannaStore' }
    )
);
