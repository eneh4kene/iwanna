import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type {
    AppState,
    AuthState,
    WannaState,
    PodState,
    ChatState,
    LocationState,
    User,
    Wanna,
    Pod,
    ChatMessage,
    Location,
    AuthTokens,
    DeviceInfo,
    CreateAccountForm,
    RecoverAccountForm,
} from '../types';

// Auth Store (Phase 1B: Anonymous-first authentication)
interface AuthStore extends AuthState {
    // Core auth actions
    createAccount: (form: CreateAccountForm) => Promise<void>;
    recoverAccount: (form: RecoverAccountForm) => Promise<void>;
    login: (user: User, tokens: AuthTokens) => void;
    logout: () => void;
    refreshToken: () => Promise<void>;

    // Account management
    updateUser: (user: Partial<User>) => void;
    upgradeToEmail: (email: string) => Promise<void>;
    upgradeToSocial: (provider: 'google' | 'apple', credential: string) => Promise<void>;

    // State management
    setLoading: (loading: boolean) => void;
    setError: (error: string | undefined) => void;
    clearRecoveryPhrase: () => void;

    // Rate limiting
    checkRateLimit: () => Promise<{ allowed: boolean; remaining: number }>;
}

export const useAuthStore = create<AuthStore>()(
    devtools(
        persist(
            immer((set, get) => ({
                isAuthenticated: false,
                user: undefined,
                tokens: undefined,
                isLoading: false,
                error: undefined,
                recoveryPhrase: undefined,

                createAccount: async (form: CreateAccountForm) => {
                    try {
                        set((state) => {
                            state.isLoading = true;
                            state.error = undefined;
                        });

                        // Import API service dynamically to avoid circular imports
                        const { apiService } = await import('../services/api');

                        const response = await apiService.createAnonymousAccount(form);

                        if (response.success && response.data) {
                            const { userId, username, token, refreshToken, recoveryPhrase, accountTier } = response.data;

                            const tokens: AuthTokens = {
                                accessToken: token,
                                refreshToken: refreshToken,
                                expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
                            };

                            const user: User = {
                                id: userId,
                                username,
                                accountTier,
                                createdAt: new Date(),
                                lastActive: new Date(),
                                trustScore: 100,
                                wannasCreated: 0,
                                podsJoined: 0,
                                connectionsMade: 0,
                            };

                            set((state) => {
                                state.isAuthenticated = true;
                                state.user = user;
                                state.tokens = tokens;
                                state.recoveryPhrase = recoveryPhrase;
                                state.error = undefined;
                            });
                        } else {
                            throw new Error(response.error?.message || 'Account creation failed');
                        }
                    } catch (error) {
                        set((state) => {
                            state.error = error instanceof Error ? error.message : 'Account creation failed';
                        });
                        throw error;
                    } finally {
                        set((state) => {
                            state.isLoading = false;
                        });
                    }
                },

                recoverAccount: async (form: RecoverAccountForm) => {
                    try {
                        set((state) => {
                            state.isLoading = true;
                            state.error = undefined;
                        });

                        const { apiService } = await import('../services/api');

                        const response = await apiService.recoverAccount(form);

                        if (response.success && response.data) {
                            const { userId, username, token, refreshToken } = response.data;

                            const tokens: AuthTokens = {
                                accessToken: token,
                                refreshToken: refreshToken,
                                expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
                            };

                            // Fetch full user profile
                            const userResponse = await apiService.getCurrentUser();

                            if (userResponse.success && userResponse.data) {
                                set((state) => {
                                    state.isAuthenticated = true;
                                    state.user = userResponse.data.user;
                                    state.tokens = tokens;
                                    state.error = undefined;
                                });
                            }
                        } else {
                            throw new Error(response.error?.message || 'Account recovery failed');
                        }
                    } catch (error) {
                        set((state) => {
                            state.error = error instanceof Error ? error.message : 'Account recovery failed';
                        });
                        throw error;
                    } finally {
                        set((state) => {
                            state.isLoading = false;
                        });
                    }
                },

                login: (user: User, tokens: AuthTokens) =>
                    set((state) => {
                        state.isAuthenticated = true;
                        state.user = user;
                        state.tokens = tokens;
                        state.error = undefined;
                    }),

                logout: async () => {
                    try {
                        const { apiService } = await import('../services/api');
                        const tokens = get().tokens;

                        if (tokens?.refreshToken) {
                            await apiService.logout(tokens.refreshToken);
                        }
                    } catch (error) {
                        console.error('Logout error:', error);
                    } finally {
                        set((state) => {
                            state.isAuthenticated = false;
                            state.user = undefined;
                            state.tokens = undefined;
                            state.error = undefined;
                            state.recoveryPhrase = undefined;
                        });
                    }
                },

                refreshToken: async () => {
                    try {
                        const { apiService } = await import('../services/api');
                        const tokens = get().tokens;

                        if (!tokens?.refreshToken) {
                            throw new Error('No refresh token');
                        }

                        const response = await apiService.refreshToken(tokens.refreshToken);

                        if (response.success && response.data) {
                            const newTokens: AuthTokens = {
                                ...tokens,
                                accessToken: response.data.token,
                                expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
                            };

                            set((state) => {
                                state.tokens = newTokens;
                            });
                        }
                    } catch (error) {
                        // Refresh failed - logout
                        await get().logout();
                        throw error;
                    }
                },

                updateUser: (userData: Partial<User>) =>
                    set((state) => {
                        if (state.user) {
                            Object.assign(state.user, userData);
                        }
                    }),

                upgradeToEmail: async (email: string) => {
                    try {
                        const { apiService } = await import('../services/api');
                        await apiService.upgradeToEmail(email);

                        // Refresh user data
                        const response = await apiService.getCurrentUser();
                        if (response.success && response.data) {
                            set((state) => {
                                state.user = response.data.user;
                            });
                        }
                    } catch (error) {
                        set((state) => {
                            state.error = error instanceof Error ? error.message : 'Email upgrade failed';
                        });
                        throw error;
                    }
                },

                upgradeToSocial: async (provider: 'google' | 'apple', credential: string) => {
                    try {
                        const { apiService } = await import('../services/api');
                        await apiService.upgradeToSocial(provider, credential);

                        // Refresh user data
                        const response = await apiService.getCurrentUser();
                        if (response.success && response.data) {
                            set((state) => {
                                state.user = response.data.user;
                            });
                        }
                    } catch (error) {
                        set((state) => {
                            state.error = error instanceof Error ? error.message : 'Social upgrade failed';
                        });
                        throw error;
                    }
                },

                checkRateLimit: async () => {
                    const { apiService } = await import('../services/api');
                    const response = await apiService.checkRateLimit();

                    if (response.success && response.data) {
                        return {
                            allowed: response.data.allowed,
                            remaining: response.data.remaining,
                        };
                    }

                    throw new Error('Rate limit check failed');
                },

                setLoading: (loading: boolean) =>
                    set((state) => {
                        state.isLoading = loading;
                    }),

                setError: (error: string | undefined) =>
                    set((state) => {
                        state.error = error;
                    }),

                clearRecoveryPhrase: () =>
                    set((state) => {
                        state.recoveryPhrase = undefined;
                    }),
            })),
            {
                name: 'iwanna-auth',
                partialize: (state) => ({
                    isAuthenticated: state.isAuthenticated,
                    user: state.user,
                    tokens: state.tokens,
                }),
            }
        ),
        { name: 'AuthStore' }
    )
);

// Wanna Store
interface WannaStore extends WannaState {
    setActiveWannas: (wannas: Wanna[]) => void;
    addWanna: (wanna: Wanna) => void;
    updateWanna: (id: string, updates: Partial<Wanna>) => void;
    removeWanna: (id: string) => void;
    setLoading: (loading: boolean) => void;
    setError: (error: string | undefined) => void;
}

export const useWannaStore = create<WannaStore>()(
    devtools(
        immer((set) => ({
            activeWannas: [],
            isLoading: false,
            error: undefined,

            setActiveWannas: (wannas: Wanna[]) =>
                set((state) => {
                    state.activeWannas = wannas;
                }),

            addWanna: (wanna: Wanna) =>
                set((state) => {
                    state.activeWannas.push(wanna);
                }),

            updateWanna: (id: string, updates: Partial<Wanna>) =>
                set((state) => {
                    const index = state.activeWannas.findIndex((w) => w.id === id);
                    if (index !== -1) {
                        Object.assign(state.activeWannas[index], updates);
                    }
                }),

            removeWanna: (id: string) =>
                set((state) => {
                    state.activeWannas = state.activeWannas.filter((w) => w.id !== id);
                }),

            setLoading: (loading: boolean) =>
                set((state) => {
                    state.isLoading = loading;
                }),

            setError: (error: string | undefined) =>
                set((state) => {
                    state.error = error;
                }),
        })),
        { name: 'WannaStore' }
    )
);

// Pod Store
interface PodStore extends PodState {
    setActivePods: (pods: Pod[]) => void;
    addPod: (pod: Pod) => void;
    updatePod: (id: string, updates: Partial<Pod>) => void;
    removePod: (id: string) => void;
    setLoading: (loading: boolean) => void;
    setError: (error: string | undefined) => void;
}

export const usePodStore = create<PodStore>()(
    devtools(
        immer((set) => ({
            activePods: [],
            isLoading: false,
            error: undefined,

            setActivePods: (pods: Pod[]) =>
                set((state) => {
                    state.activePods = pods;
                }),

            addPod: (pod: Pod) =>
                set((state) => {
                    state.activePods.push(pod);
                }),

            updatePod: (id: string, updates: Partial<Pod>) =>
                set((state) => {
                    const index = state.activePods.findIndex((p) => p.id === id);
                    if (index !== -1) {
                        Object.assign(state.activePods[index], updates);
                    }
                }),

            removePod: (id: string) =>
                set((state) => {
                    state.activePods = state.activePods.filter((p) => p.id !== id);
                }),

            setLoading: (loading: boolean) =>
                set((state) => {
                    state.isLoading = loading;
                }),

            setError: (error: string | undefined) =>
                set((state) => {
                    state.error = error;
                }),
        })),
        { name: 'PodStore' }
    )
);

// Chat Store
interface ChatStore extends ChatState {
    setMessages: (podId: string, messages: ChatMessage[]) => void;
    addMessage: (podId: string, message: ChatMessage) => void;
    setTypingUsers: (podId: string, userIds: string[]) => void;
    addTypingUser: (podId: string, userId: string) => void;
    removeTypingUser: (podId: string, userId: string) => void;
    setLoading: (loading: boolean) => void;
    setError: (error: string | undefined) => void;
}

export const useChatStore = create<ChatStore>()(
    devtools(
        immer((set) => ({
            messages: {},
            typingUsers: {},
            isLoading: false,
            error: undefined,

            setMessages: (podId: string, messages: ChatMessage[]) =>
                set((state) => {
                    state.messages[podId] = messages;
                }),

            addMessage: (podId: string, message: ChatMessage) =>
                set((state) => {
                    if (!state.messages[podId]) {
                        state.messages[podId] = [];
                    }
                    state.messages[podId].push(message);
                }),

            setTypingUsers: (podId: string, userIds: string[]) =>
                set((state) => {
                    state.typingUsers[podId] = userIds;
                }),

            addTypingUser: (podId: string, userId: string) =>
                set((state) => {
                    if (!state.typingUsers[podId]) {
                        state.typingUsers[podId] = [];
                    }
                    if (!state.typingUsers[podId].includes(userId)) {
                        state.typingUsers[podId].push(userId);
                    }
                }),

            removeTypingUser: (podId: string, userId: string) =>
                set((state) => {
                    if (state.typingUsers[podId]) {
                        state.typingUsers[podId] = state.typingUsers[podId].filter(
                            (id) => id !== userId
                        );
                    }
                }),

            setLoading: (loading: boolean) =>
                set((state) => {
                    state.isLoading = loading;
                }),

            setError: (error: string | undefined) =>
                set((state) => {
                    state.error = error;
                }),
        })),
        { name: 'ChatStore' }
    )
);

// Location Store
interface LocationStore extends LocationState {
    setCurrentLocation: (location: Location) => void;
    setTracking: (tracking: boolean) => void;
    setPermissionStatus: (status: 'granted' | 'denied' | 'undetermined') => void;
    setError: (error: string | undefined) => void;
}

export const useLocationStore = create<LocationStore>()(
    devtools(
        immer((set) => ({
            currentLocation: undefined,
            isTracking: false,
            permissionStatus: 'undetermined',
            error: undefined,

            setCurrentLocation: (location: Location) =>
                set((state) => {
                    state.currentLocation = location;
                }),

            setTracking: (tracking: boolean) =>
                set((state) => {
                    state.isTracking = tracking;
                }),

            setPermissionStatus: (status: 'granted' | 'denied' | 'undetermined') =>
                set((state) => {
                    state.permissionStatus = status;
                }),

            setError: (error: string | undefined) =>
                set((state) => {
                    state.error = error;
                }),
        })),
        { name: 'LocationStore' }
    )
);

// Combined store selector for easy access
export const useAppStore = () => ({
    auth: useAuthStore(),
    wannas: useWannaStore(),
    pods: usePodStore(),
    chat: useChatStore(),
    location: useLocationStore(),
});

// Store actions for common operations
export const storeActions = {
    // Clear all stores (useful for logout)
    clearAll: () => {
        useAuthStore.getState().logout();
        useWannaStore.getState().setActiveWannas([]);
        usePodStore.getState().setActivePods([]);
        useChatStore.getState().setMessages('', []);
        useLocationStore.getState().setCurrentLocation(undefined);
    },

    // Reset error states
    clearErrors: () => {
        useAuthStore.getState().setError(undefined);
        useWannaStore.getState().setError(undefined);
        usePodStore.getState().setError(undefined);
        useChatStore.getState().setError(undefined);
        useLocationStore.getState().setError(undefined);
    },
};
